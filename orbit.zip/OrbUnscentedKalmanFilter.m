classdef OrbUnscentedKalmanFilter < OrbFilter
    %UNTITLED3 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        residualPlot;
        svnPlot;
        recClcBiasPlot;
        innovationPlot;
        %recClcdriftPlot;
        chiSquareDist=[ % resource: http://sites.stat.psu.edu/~mga/401/tables/Chi-square-table.pdf
                0.995  0.990  0.975  0.950  0.900  0.100  0.050  0.025  0.010  0.005   % dof
                0.000  0.000  0.001  0.004  0.016  2.706  3.841  5.024  6.635  7.879   % 1
                0.010  0.020  0.051  0.103  0.211  4.605  5.991  7.378  9.210  10.597  % 2
                0.072  0.115  0.216  0.352  0.584  6.251  7.815  9.348  11.345 12.838  % 3
                0.207  0.297  0.484  0.711  1.064  7.779  9.488  11.143 13.277 14.860  % 4
                0.412  0.554  0.831  1.145  1.610  9.236  11.070 12.833 15.086 16.750  % 5
                0.676  0.872  1.237  1.635  2.204  10.645 12.592 14.449 16.812 18.548  % 6
                0.989  1.239  1.690  2.167  2.833  12.017 14.067 16.013 18.475 20.278  % 7
                1.344  1.646  2.180  2.733  3.490  13.362 15.507 17.535 20.090 21.955  % 8
                1.735  2.088  2.700  3.325  4.168  14.684 16.919 19.023 21.666 23.589  % 9
                2.156  2.558  3.247  3.940  4.865  15.987 18.307 20.483 23.209 25.188  % 10
                2.603  3.053  3.816  4.575  5.578  17.275 19.675 21.920 24.725 26.757  % 11
                3.074  3.571  4.404  5.226  6.304  18.549 21.026 23.337 26.217 28.300  % 12
                3.565  4.107  5.009  5.892  7.042  19.812 22.362 24.736 27.688 29.819  % 13
                4.075  4.660  5.629  6.571  7.790  21.064 23.685 26.119 29.141 31.319  % 14
                4.601  5.229  6.262  7.261  8.547  22.307 24.996 27.488 30.578 32.801  % 15
                5.142  5.812  6.908  7.962  9.312  23.542 26.296 28.845 32.000 34.267  % 16
                5.697  6.408  7.564  8.672  10.085 24.769 27.587 30.191 33.409 35.718  % 17
                6.265  7.015  8.231  9.390  10.865 25.989 28.869 31.526 34.805 37.156  % 18
                6.844  7.633  8.907  10.117 11.651 27.204 30.144 32.852 36.191 38.582  % 19
                7.434  8.260  9.591  10.851 12.443 28.412 31.410 34.170 37.566 39.997  % 20
                8.034  8.897  10.283 11.591 13.240 29.615 32.671 35.479 38.932 41.401  % 21
                8.643  9.542  10.982 12.338 14.041 30.813 33.924 36.781 40.289 42.796  % 22
                9.260  10.196 11.689 13.091 14.848 32.007 35.172 38.076 41.638 44.181  % 23
                9.886  10.856 12.401 13.848 15.659 33.196 36.415 39.364 42.980 45.559  % 24
                10.520 11.524 13.120 14.611 16.473 34.382 37.652 40.646 44.314 46.928];% 25
        
    end
    
    methods
        function this=OrbUnscentedKalmanFilter()
            
        % Create the figure handles for online plots
          this.residualPlot=figure;
          this.svnPlot=figure;
          this.recClcBiasPlot=figure;
          this.innovationPlot=figure;
          %this.recClcdriftPlot=figure
        end
        
        function [predSVobj]=timeUpdate(this,initSVObj,dt)
        % FUNCTION
        %   Function propagete the state vector and covariance matrix to 
        %   through the time.
        % INPUTS
        %   initSVObj: instance of 'OrbStateVector' class including initial 
        %              state vector and covariance matrix
        %   dt       : propagation time interval in second 
        % OUTPUTS
        %   predSVobj: instance of 'OrbStateVector' class including propagated 
        %              sigma vector and their mean value and covariance matrix 
        %---------------------------------------------------------------- 
        
        % Compute Sigma-Vectors and their weights
          [xs,wC,wS]=this.computeSigmaPoints(initSVObj.stateVector,...
                                             initSVObj.stateCov);
        % Create instance of 'OrbStateVector' class to store sigma vectors
          initSigmaSVobj=OrbStateVector(xs,...
                                        this.filtSet.enableDynModParam, ...
                                        this.filtSet.obsType, ...
                                        initSVObj.stateFateTime);
        % Propagate the each sigma vectors 
          [xSigma]=this.dynModelObj.propagateState(initSigmaSVobj,dt,dt);
        % Compute the mean and covaraince of state vector from the
        % sigma-vectors
          [xp,Pp]=this.predictedMeanCov(xSigma,wC,wS);
        % Get the process noise
          Q=this.dynModelObj.getProcessNoise(initSVObj,dt);
        % Update predicted covariance matrix with computed process noise  
          Pp=Pp+Q;
        % Set the output parameter
          % Compute time of prediction
            initDTobj=FateTime(initSVObj.stateFateTime);          
            predDTobj=plus(initDTobj,dt);
            predStateFateTime=[get(predDTobj,'year'),...
                               get(predDTobj,'month'),...
                               get(predDTobj,'day'),...
                               get(predDTobj,'hour'),...
                               get(predDTobj,'min'),...
                               get(predDTobj,'sec')];    
          % Set parameters
            predSVobj=OrbStateVector(xp,...
                                     this.filtSet.enableDynModParam, ...
                                     this.filtSet.obsType, ...
                                     initSVObj.stateFateTime);
            predSVobj.stateCov=Pp;                      
            predSVobj.stateFateTime=predStateFateTime;
            predSVobj.updateFlag=1;
        end
        
        function [updSVobj,updEDobj,updateFlag]=measurementUpdate(this, ...
                                              prevEDobj,currEDobj,predSVobj,initSVObj)
        %-----------------------------------------------------------------             
        % FUNCTION
        %   Function performs a data editing step to remove outliers and to
        %   control elevation threshold. Than execute measurement update step 
        %   of Kalman filtering  
        % INPUTS
        %   prevEDobj : instance of 'OrbEpochData' class including observations
        %               GPS ephemerides and other auxiliary data at the
        %               previous time of epoch
        %   currEDobj : instance of 'OrbEpochData' class including observations
        %               GPS ephemerides and other auxiliary data at the
        %               current time of epoch        
        %   predSVobj : instance of 'OrbStateVector' class including predicted 
        %               state vector variables  
        % OUTPUTS
        %   updSVobj : instance of 'OrbStateVector' class including updated 
        %              state vector variables          
        %   updEDobj : instance of 'OrbEpochData' class including updated 
        %              observations, GPS ephemerides and other auxiliary data
        %   updateFlag : If measurement update step is carried out without
        %                any problem updateFlag takes the value "0", else
        %                "1". If updateFlag takes "1",updSVobj andu pdEDobj
        %                variables are set to empty value "[]"
        %   minObsFlag  : If number of minimum observations is under the 
        %                 threshold, minObsFlag takes value '1' else value '0'
        %----------------------------------------------------------------- 

        % Set the default value for the update flag
          updateFlag=0;
        
        % Prior to measurement update, perform date editing process
          if strcmp(this.filtSet.obsType,'Graphic')
             [updSVobj,updEDobj,minObsFlag]=this.measModelObj.dataEditing(...
                                         prevEDobj,currEDobj,predSVobj);
          elseif strcmp(this.filtSet.obsType,'Code')
             [updSVobj,updEDobj,minObsFlag]=this.measModelObj.dataEditing(...
                                                   currEDobj,predSVobj);
          elseif strcmp(this.filtSet.obsType,'NavSol')
             [updSVobj,updEDobj,minObsFlag]=this.measModelObj.dataEditing(...
                                                   currEDobj,predSVobj);
          else
              error('Wrong unsupported observation type')                                               
          end
          % Control the number of minumum observations
            if minObsFlag==1
               updateFlag=1; updSVobj=[]; updEDobj=[];
               return;
            end
            
        % Unscented Kalman Update
          [updSVobj]=unscentedKalmanUpdate(this,updSVobj,updEDobj,initSVObj,currEDobj);         
        % Set the state update vector
          updSVobj.updateFlag=0;
         
        end
        
        function [updSVobj]=unscentedKalmanUpdate(this,SVobj,EDobj,initSVObj,currEDobj)
        % FUNCTION
        %   Function performs Kalman update equations
        % INPUTS
        %   EDobj : instance of 'OrbEpochData' class including observations
        %           GPS ephemerides and other auxiliary data
        %   SVobj : instance of 'OrbStateVector' class including state
        %           vector variables  
        % OUTPUTS
        %   updSVobj: instance of 'OrbStateVector' class including updated 
        %             state vector and covariance matrix 
        %----------------------------------------------------------------  
        global ino;
        % Set initial values
          xp=SVobj.stateVector; Pp=SVobj.stateCov;
        % Recompute sigma-vectors due to data editing and edition of process 
        % noise covariance 
          [xs,wC,wS]=this.computeSigmaPoints(xp,Pp);
        % Set the computed observations for each sigma point   
          [nS,mS]=size(xs);
          for k=1:mS
              sigmaSVobj=OrbStateVector(xs(:,k),...
                                        this.filtSet.enableDynModParam, ...
                                        this.filtSet.obsType, ...
                                        SVobj.stateFateTime);
              [zc(:,k)]=this.measModelObj.getCompObs(EDobj,sigmaSVobj);
          end 
        % Get the observations
          if strcmp(this.filtSet.obsType,'Graphic')
             z=EDobj.obs.Graphic; 
          elseif strcmp(this.filtSet.obsType,'Code')
             z=EDobj.obs.C1;  
          elseif strcmp(this.filtSet.obsType,'NavSol')
               z=EDobj.obs.NavSol;                 
          end
        % Compute Measurement Noise
          n=length(z);
          if strcmp(this.filtSet.obsType,'Graphic') ||...
             strcmp(this.filtSet.obsType,'Code')
              R=this.filtSet.stat.std.measurementNoise^2*eye(n);
          elseif strcmp(this.filtSet.obsType,'NavSol')
              R=diag(this.filtSet.stat.std.measurementNoise.^2);
          end      
        % Predicted mean observation (zpp) and innovation covariance (Pzz)
          [zp,Pzz]=this.predictedMeanCov(zc,wC,wS); %zc gama olmal�
        % Innovations
          v=z-zp;
          ino = ino + 1;
        % If robust filtering option enabled, search for failure detection,
        % if it fails, compute weight matrix to decrease the effect of
        % badly conditioned measurements
          if this.filtSet.dataEditing.mode==2 % robust filtering mode
            [S, faultyFlag]=this.computeRobustFilteringWeight(Pzz,R,v,currEDobj);
            Pzzr=Pzz+S*R;  % Updated innovation covariance

          elseif this.filtSet.dataEditing.mode==1 % iterative outlier detection mode 
            Pzzr=Pzz+R;    % Updated innovation covariance
            S=eye(length(v));
          end      
 
        % Cross correlation (Pxz)
          [Pxz]=this.crossCorrelation(SVobj.stateVector,xs,zp,zc,wC);
        % Filter Gain K
          %K=Pxz*inv(Pzz);
          K=Pxz/Pzzr;
        % Update predicted state and covaraiance
          % Update state
            xc=xp+K*v;
          % Update covaraiance
            Pc=Pp-K*Pzzr*K'; 
            SVobj.recClcBias
            
            
%'Pv'
[H]=this.measModelObj.getDesignMatrix(EDobj,SVobj);
%diag(H*Pp*H')'

%{
'v'
v'
'Pp'
diag(Pp)'
'Pc'
diag(Pc)'
'xc'
xc'
% 'Pdiff'
% diag(Pc)-diag(Pp)
%}
        % Set function output 
          updSVobj=OrbStateVector(xc,...
                                  this.filtSet.enableDynModParam, ...
                                  this.filtSet.obsType, ...
                                  SVobj.stateFateTime);
          updSVobj.stateCov=Pc;
          [rS,cS] = size(S);
          updSVobj.covSclMat=S;
          updSVobj.innov=v;
        % Update time of state vector due to receiver clock correction 
          if strcmp(this.filtSet.obsType,'Code') || ...
             strcmp(this.filtSet.obsType,'Graphic')   
             c = 299792458;          % speed of light in vacum (m/sec)
             stateDTobj=FateTime(SVobj.stateFateTime);
             updDTobj=plus(stateDTobj,updSVobj.recClcBias/c);
             updSVobj.stateFateTime =[get(updDTobj,'year'), get(updDTobj,'month'),...
                                      get(updDTobj,'day') ,get(updDTobj,'hour'),...
                                      get(updDTobj,'min'),get(updDTobj,'sec')];
          end
          
          %recClcBdrfit = (updSVobj.recClcBias-initSVObj.recClcBias)/30
        % Post-fit residuals
          rp =z - this.measModelObj.getCompObs(EDobj,updSVobj);

        % Online Plots
          % Plot the innovations
            filterCurrentTimeObj=FateTime(SVobj.stateFateTime);
            filterInitTimeObj=FateTime(this.filterInitTime);
            dt=minus(filterCurrentTimeObj,filterInitTimeObj);
            figure(this.innovationPlot)
            plot(dt*ones(length(rp),1),v,'.','MarkerSize',5)
            ylabel ('Innovation Plot');
            hold on
          % Plot the residuals
            filterCurrentTimeObj=FateTime(SVobj.stateFateTime);
            filterInitTimeObj=FateTime(this.filterInitTime);
            dt=minus(filterCurrentTimeObj,filterInitTimeObj);
            figure(this.residualPlot)
            plot(dt*ones(length(rp),1),rp,'.','MarkerSize',5)
            ylabel ('Residual Plot');
            hold on            
          % Plot the tracked satellites
            figure(this.svnPlot)
            plot(dt*ones(length(v),1),EDobj.svn,'>','MarkerSize',5)
            ylabel ('Tracked Satellites');
            hold on       
%           % Plot the receiver clock bias
            figure(this.recClcBiasPlot)
            plot(dt,updSVobj.recClcBias,'.','MarkerSize',5)
            ylabel ('Receiver Clock Bias');
            hold on
            % Plot the receiver clock bias drift
            %figure(this.recClcdriftPlot)
            %plot(dt,recClcBdrfit,'.','MarkerSize',5)
            %ylabel ('Receiver Clock Bias Drift');
            %hold on
pause(0.01)             
        end
        
        function [xs,Wc,Wm]=computeSigmaPoints(this,x,P)
        % FUNCTION
        %   Function computes the sigma points and weights for each sigma
        %   point and covarainces
        % INPUTS
        %   x         : mean value of the state vector
        %   P         : covaraince of the mean state vector
        % OUTPUTS
        %   xs        : array including state vectors for each sigma points
        %   Wm        : array including weights for each sigma points
        %   Wc        : array including weights for covariance each sigma points
        %----------------------------------------------------------------              
        % Size of state vector
          [n,m]=size(x);
        % Scaling parameter lambda
          if isempty (this.filtSet.UKF.kappa)
             kAppa=3-n;
          else
             kAppa= this.filtSet.UKF.kappa;
          end
          aLfa=this.filtSet.UKF.alfa;
          bEta=this.filtSet.UKF.beta;  
          lAmbda=aLfa^2*(n+kAppa)-n;
        % Covariance scaling factor
          scale_fact=sqrt(n+lAmbda);
        % Matrix quare root of scaled covaraiance; Ps=C'C
          C=chol(P);
        % Sigma points(xs) and associated weights (Wm,Wc)  
          xs(:,1)=x;
          Wm(1)=lAmbda/(n+lAmbda);
          Wc(1)=lAmbda/(n+lAmbda)+(1-aLfa^2+bEta);
          for i=2:n+1
              xs(:,i)=x+scale_fact*C(i-1,:)';
              xs(:,i+n)=x-scale_fact*C(i-1,:)';
              Wm(i)=1/(2*(n+lAmbda));
              Wm(i+n)=Wm(i);  
              Wc(i)=Wm(i);
              Wc(i+n)=Wm(i); 
          end
        end   
        
        function [xp,Pp]=predictedMeanCov(this,xs,Wc,Wm)
        % FUNCTION
        %   Function computes predicted state vector mean and covariance
        %   from the sigma points
        % OUTPUTS
        %   xp or zp         : mean value of the state vector or Predicted mean observation
        %   Pp or Pzz       : covaraince of the mean state vector or innovation covariance (Pzz)
        % INPUTS
        %   xs        : array including state vectors for each sigma points
        %               or computed observations for each sigma point (zc,
        %               gamma is used in journal instead of zc)
        %   Wm        : array including weights for each sigma points
        %   Wc        : array including weights for covariance each sigma points
        %----------------------------------------------------------------  
        %{
        Her sigma point i�in hesaplam�� oldu�u obs'lara (gama veya zc) Wm a��rl�k
        de�eri ile �arparak hepsini topluyor ve predicted mean obs: zp buluyor. Daha
        sonra da zc'nin her bir s�tunu (yani computed obs vect�r�)nden zp'yi ��kar�p 
        fark�n�n karesini da sigma point covariance weight ile �arp�p hepsini topluyor.
        Sonucunda inovasyon cov bulunuyor.
        %}
        % Size of sigma points
          [m,n]=size(xs);
        % Predicted mean
          xp=Wm(1)*xs(:,1); % or zp: predicted mean obs
          for i=2:n
             xp=xp+Wm(i)*xs(:,i); % or zp: predicted mean obs
          end
        % Predicted covariance
          Pp=Wc(1)*(xs(:,1)-xp)*(xs(:,1)-xp)'; % or innovation covariance (Pzz)       
          for i=2:n
             Pp=Pp+Wc(i)*(xs(:,i)-xp)*(xs(:,i)-xp)';%or innovation covariance (Pzz)   
          end      

        end
        
        function [Pxz]=crossCorrelation(this,xp,xs,zp,zs,Wc)
        % FUNCTION
        %   Function estimates cross correlation between to sigma points
        %   and observables
        % INPUTS
        %   xp    : mean value of sigma points
        %   xs    : sigma points
        %   zp    : mean value of computed observables
        %   zs    : computed observables obtained using sigma points
        %   Wc    : array including weights for covariance 
        % OUTPUTS
        %   Pxz   : estimated cross-correlation matrix
        %----------------------------------------------------------------             
        % Number of sigma points (m)     
          [m,n]=size(xs);
        % Cross correlation matrix (Pxz) 
          Pxz=Wc(1)*(xs(:,1)-xp)*(zs(:,1)-zp)';  
          for i=2:n
              Pxz=Pxz+Wc(i)*(xs(:,i)-xp)*(zs(:,i)-zp)';     
          end
            
        end     
        
        function [S, faultyFlag]=computeRobustFilteringWeight(this,Pzz,R,v,currEDobj)
        % FUNCTION
        %   Function checks the filter's statatistics to detect possible
        %   faulty measurements. If any, a weighting factor is computed. 
        % INPUTS
        %   Pzz   : innovation covariance
        %   R     : Measurement noise covaraiance matrix
        %   v     : innovations 
        % OUTPUTS
        %   S          : weighting factor. If no faulty measurement
        %                detected, S is an identity matrix.
        %   faultyFlag : If any faulty measurement is detected, faultyFlag 
        %                takes the value of 1 or else 0. 
        % REFERENCES
        %   Soken H.E., Hajiyev C., Robust UKF insensitive to Measurement 
        %   Faults for Pica Satellite Attitude Estimation, World Acedemy of
        %   Science, Engineering and Technology, 44, 2010.
        %----------------------------------------------------------------  
        global c;
        global out_lier;
        global bars;
        global k;
        % Failure Detection
          % Compute statistical function to evaluate
            beta_=v'*inv(Pzz+R)*v;
          % Get the theoritical probability of chi-square distribution from
          % the table
            los=this.filtSet.dataEditig.chiSquare.los; % level of significancy;
            n=length(v); % degree of fredom
            col_num=this.chiSquareDist(1,:)==los;
            row_num=n+1;
            chi_square_prob=this.chiSquareDist(row_num,col_num);
          % Chech the distribution
            if beta_ <= chi_square_prob
               faultyFlag=0;
            else
               faultyFlag=1; 
            end
        % If any failure detected, compute weight matrix
          if faultyFlag==0 % no failure
             S=eye(n);
             
          else
             % Compute the weight martrix 
               S=(v*v'-Pzz)*inv(R); 
               
               %{
'vv'
v*v'
'Pzz'
Pzz  
'vv-Pzz'
v*v'-Pzz
%}
             % Correct the numerical errors
               S=diag(S);        % only use dioganal elements
                
               c = c+1;
               
               for i = 1:(length(S))
                   if S(i)>1
                       bars{k,1}= currEDobj.epochFateTime;
                       bars{k,2}= currEDobj.obs;
                       k = k+1;
                   end
               end
           
               bad_val_ind=S<1;  % Detect element lesser than 1
               S(bad_val_ind)=1; % Set the badly conditioned elements to 1
               S=diag(S);        % re-form the matrix S
               out_lier{c,1} = currEDobj.epochFateTime;
               out_lier{c,2} = currEDobj.obs;
               
               
               
          end

        end
        
    end
    
end

