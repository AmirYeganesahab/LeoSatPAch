% Main program
% Calculates satellite coordinates for a given epoch with use of standard
% orbits for both precise and broadcast ephemerides

clear; clc; %clear classes
format long g

% INPUT
    epo = FateTime(2005,1,1,7,14,0) ; % Current epoch
    prn = 1 % Satellite number 


% CONSTRUCTORS

    PEph = CoordEph; % Creates a tabular orbit instance 
    BEph = CoordEph; 
    StdPe = StdOrb; % Creates a standard orbit instance
    StdBr = StdOrb; 
    
% READ PRECISE EPHEMERIDES

    PEph = ReadEphPrecise(PEph,'igs13036.sp3');

    
% READ BROADCAST EPHEMERIDES
   
   [BEph, OrbPar] = ReadEphBroadcast(BEph,'auto0010.05n',15*60);
    
% READ GROUP DELAY FROM BROADCAST EPHEMERIDES

    stTgd = getTgd('auto0010.05n')
    
% DETERMINE STANDARD ORBITS    
    StdPe = CompStdOrb(StdPe,PEph,stTgd);
    StdBr = CompStdOrb(StdBr,BEph,stTgd);
    
% CALCULATE COORDINATES 

    coordsPe = GetSatCoord(StdPe,prn,epo)
    coordsBr = GetSatCoord(StdBr,prn,epo)