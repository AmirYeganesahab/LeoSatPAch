function base = EphHeader(indata)
% Navigation file header data, stored in the following parameters
%
% RINEX VERSION         : iRinexVersion
% File Type             : sFileType
% Name of Program       : sPGM
% Name of Agency        : sRunBy
% Date of File Creation : sDate
% Comment               : sComment
% Ionosphere param. A0  : dAlfaIon1
% Ionosphere param. A1  : dAlfaIon2
% Ionosphere param. A2  : dAlfaIon3
% Ionosphere param. A3  : dAlfaIon4
% Ionosphere param. B0  : dBetaIon1
% Ionosphere param. B1  : dBetaIon2
% Ionosphere param. B2  : dBetaIon3
% Ionosphere param. B3  : dBetaIon4
% Delta-UTC A0          : dA0
% Delta-UTC A1          : dA1
% Reference Time        : dRefTime
% Reference Week        : dRefWeek
% Leap second           : iLeapSeconds
%
%
% The class contains the following functions
%
%   display(A)    - All data in A are displayed in fprintf style
%   set(A,par,in) - Set one of the parameters in A
%   get(A,par)    - Get one parameter
%

switch nargin
    
    case 0
    % no arguments
        s = struct('iRinexVersion',0,'sFileType','','sPGM','','sRunBy','','sDate','','sComment','',...
        'dAlfaIon1',0,'dAlfaIon2',0,'dAlfaIon3',0,'dAlfaIon4',0,...
        'dBetaIon1',0,'dBetaIon2',0,'dBetaIon3',0,'dBetaIon4',0,...
        'dA0',0,'dA1',0,'dRefTime',0,'dRefWeek',0,...
        'iLeapSeconds',0);
        base = class(s,'EphHeader');
    case 1 
            
        s = struct('iRinexVersion',indata.iRinexVersion,...
            'sFileType',indata.sFileType,'sPGM',indata.sPGM,'sRunBy',indata.sRunBy,'sDate',indata.sDate,...
            'sComment',indata.sComment,'dAlfaIon1',indata.dAlfaIon1,'dAlfaIon2',indata.dAlfaIon2,'dAlfaIon3',indata.dAlfaIon3,...
          'dAlfaIon4',indata.dAlfaIon4,'dBetaIon1',indata.dBetaIon1,'dBetaIon2',indata.dBetaIon2,'dBetaIon3',indata.dBetaIon3,...
            'dBetaIon4',indata.dBetaIon4,'dA0',indata.dA0,'dA1',indata.dA1,'dRefTime',indata.dRefTime,'dRefWeek',indata.dRefWeek,...
           'iLeapSeconds',indata.iLeapSeconds);
          base = class(s,'EphHeader');
  end
   
    
    
