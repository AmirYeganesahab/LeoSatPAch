function display(b)

fprintf('RINEX VERSION         : %1.0i \n',b.iRinexVersion);
fprintf('File Type             : %s\n'   ,b.sFileType);
fprintf('Name of Program       : %s\n'   ,b.sPGM);
fprintf('Name of Agency        : %s\n'   ,b.sRunBy);
fprintf('Date of File Creation : %s\n'   ,b.sDate);
fprintf('Comment               : %s\n'   ,b.sComment);
fprintf('Ionosphere param. A0  : %2.0i\n',b.dAlfaIon1);
fprintf('Ionosphere param. A1  : %2.0i\n',b.dAlfaIon2);
fprintf('Ionosphere param. A2  : %2.0i\n',b.dAlfaIon3);
fprintf('Ionosphere param. A3  : %2.0i\n',b.dAlfaIon4);
fprintf('Ionosphere param. B0  : %2.0i\n',b.dBetaIon1);
fprintf('Ionosphere param. B1  : %2.0i\n',b.dBetaIon2);
fprintf('Ionosphere param. B2  : %2.0i\n',b.dBetaIon3);
fprintf('Ionosphere param. B3  : %2.0i\n',b.dBetaIon4);
fprintf('Delta-UTC A0          : %2.0i\n',b.dA0);
fprintf('Delta-UTC A1          : %2.0i\n',b.dA1);
fprintf('Reference Time        : %2.0i\n',b.dRefTime);
fprintf('Reference Week        : %2.0i\n',b.dRefWeek);
fprintf('Leap second           : %2.0i\n\n',b.iLeapSeconds);