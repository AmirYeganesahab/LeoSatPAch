function A = StdOrb()

%StdOrb - Standard orbits in form of polynoms
%dTbeg -  time of beginning [FateTime]
%dTend -  time of end [FateTime]
%dInterval - time interval of one set of coefficients [seconds]
%iPolyOrder - Number of coefficients in polynoms
%dXCoef, dYCoef, dZCoef  - matrix of coefficients for X, Y, Z coordinate, size (s,m,n).s-number of satellites, m - number
%of intevals, n - number of coefficients
%FitInt - interval used to fit the data; FitInt >= dInterval [seconds]
%dTimeSet - vector containing time of start of interval
%iPRN - satellite numbers; if iPRN == 0, no data for the satellite
%dtClTime - vector of FateTime, containing time of clock corrections stored in vector dClErr
%dClErr - vector of satellite clock corrections; clock correction for a
%given epoch is linearly interpolated

%NofCoef = 12;
iPolyOrder = 16;  %
sz = iPolyOrder + 1;  %number of polynomial coefficients
dtTime = FateTime;
s = struct('dTbeg', dtTime, 'dTend', dtTime, 'dInterval', 2*3600, 'iPolyOrder', iPolyOrder, 'dXCoef', zeros(1,1,sz), 'dXmu', zeros(1,1,2), 'dYCoef', zeros(1,1,sz), ...
   'dYmu', zeros(1,1,2), 'dZCoef', zeros(1,1,sz), 'dZmu', zeros(1,1,2),  'dFitInt', 4*3600, 'dTimeSet', dtTime, ...
   'iPRN', zeros(1,1), 'dtClTime', dtTime, 'dClErr', 0,'dTGD',0);
A = class(s, 'StdOrb');