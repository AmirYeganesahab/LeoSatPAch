function [A, data] = ReadEphBroadcast(A,sFileName,dInterval)
  
% This function reads broadcast ephemeris from a RINEX file
% and calculates the satellit position with the wanted intervall
%
% To call the function one writes:
%
%      [A, data] = ReadEphBro(A,sFileName,dInterval)
%
%   A - CoordEph instance 
%   data - EphData 
%   sFileName - filename of the RINEX file
%   dInterval - the time intervall
%
%
% The function is written by Johan Vium Andersson
% Last time updated 2005-02-01

    A=CoordEph; % Constructor

     [header,data] = brEphRinexRead(sFileName);
    
    [n m]=size(data);
    
    dLastEpoch =[];
    dFirstEpoch = [];
 % Find the first and last Epoch 
    first_time_flag = 0;  % Modfied by ERDOGAN
    for i=1:n

        for j=1:m
    
            BB(1) = get(data(i,j) , 'iEpochYear');
            BB(2) = get(data(i,j) , 'iEpochMonth');                        
            BB(3) = get(data(i,j) , 'iEpochDay');               
            BB(4) = get(data(i,j) , 'iEpochHour');               
            BB(5) = get(data(i,j) , 'iEpochMinute');        
            BB(6) = get(data(i,j) , 'iEpochSecond');    
            if abs(BB(1)) < 1e-13 % no data for this satellite
                continue;
            end
  
            dJD = FateTime(BB); % Convert the time to JD
           
            %if i==1 & j==1  %ORIGINAL
            if first_time_flag ==0
                dFirstEpoch = dJD;
                dLastEpoch = dJD;
                first_time_flag=1;

            elseif (dJD - dFirstEpoch) < 0   
            
                dFirstEpoch = dJD;
               
            elseif (dJD - dLastEpoch) > 0  
            
                dLastEpoch = dJD;
               
            end
    
        end
    end    

% Define start of the interval

    dStart = dFirstEpoch - 3*3600;

    
% Define the end of the interval

    dEnd = dLastEpoch + 3*3600;
    
    
%Time span in [s]

    TimeSpan = dEnd - dStart;
    
    
%Number of intervals
    
    Nint = floor(TimeSpan/dInterval);
    
data(1,1) = set(data(1,1), 'dtStart', dStart);
data(1,1) = set(data(1,1), 'dtEnd', dEnd);
   
% Calculate satellite coordinates for each interval
    epo = dStart; % counter
    for i = 1:Nint
        A.dTime(i) = epo;
        % Here should the resulult be placed in a CoordEph class
        vXYZ = beEphCoordCalc(data, epo);
        [iRow,iCol] = size(vXYZ);       
        for p=1:iRow
                prn = p;
                A.iPRN(prn,i) = prn;
                A.dX(prn,i)   =  vXYZ(p,1);
                A.dY(prn,i)   =  vXYZ(p,2);
                A.dZ(prn,i)   =  vXYZ(p,3);
                A.dDts(prn,i) =  vXYZ(p,4);
                A.dTGD(prn,i) =  vXYZ(p,5);
        end
        epo = epo +  dInterval;
        
    end
