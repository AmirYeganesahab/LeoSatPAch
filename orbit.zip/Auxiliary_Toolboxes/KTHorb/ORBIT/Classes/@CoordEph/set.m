function b = set(b,par,in)
b.(par)=in;

