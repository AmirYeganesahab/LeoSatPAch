function a = get(b,par)

a=b.(par);
