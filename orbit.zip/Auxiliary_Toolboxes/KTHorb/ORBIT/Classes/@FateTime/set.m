function  b= set(b,par,val)

b.(par) = val;
