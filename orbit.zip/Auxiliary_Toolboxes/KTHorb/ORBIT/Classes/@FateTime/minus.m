function r = minus(a,b)

%Computes differences between two FateTime a-b
%or FateTime a minus b seconds

%Written by Milan Horemuz, last modified 2004-11-01


if isa(a, 'FateTime') & isa(b, 'FateTime')
    [k,l] = size(a);
    [m,n] = size(b);
    if (k==m & l==n)
        dw = a.gweek - b.gweek;
        ds = a.wsec - b.wsec;
        r = dw*86400*7 + ds;
    elseif (k==1 & l>1) & (m ==1 & n==1)
        for j=1:l
            dw(j) = a(j).gweek - b.gweek;
            ds(j) = a(j).wsec - b.wsec;
            r(j) = dw(j)*86400*7 + ds(j);
        end
    end
                
        
elseif isa(a, 'FateTime') & isa(b, 'double')
    pom = a.wsec - b;
    r = FateTime(a.gweek, pom);
else
    err = sprintf('Operator minus in FateTime does not allow arguments %s %s', class(a), class(b));
    error(err);
end