In the Zip-file are two folders a main.m file and this readme.txt file.The folder DATA contains files with broadcast and precise ephemerides and folder ORBIT contains classes and methods used to determine standard orbits and to calculate coordinates.

To run the program 

	1. Place the catalogue KthOrb in a folder. 

	2. Set the path in Matlab to the folder 
	
	3. Type "main" in Matlab command window
	
	4. Read "MATLAB implementation.doc" for futher instructions


In the main-file, PRN-number and reference time can be changed. Default values are PRN01 and 2005-01-01 07:14:00

(The files are verified and working in Matlab version 6.5 and 7.0)

