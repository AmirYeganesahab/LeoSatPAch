classdef OrbitDataAnalyser < handle
    
    
    properties
        % For filter outputs in text format 
          filtEstFID
          filterType
          obsType
          enableCdragCrad
          enableEmpAccel
          enableEmpCorrTime
          filterData
          filePath
          matFilterData
        
        % For filter orutputs in mat format
          filtIntData % filter internal data
    end
    
    methods
        function this=OrbitDataAnalyser()
            
        end
        
        function readFilterOutputFiles(this,folderPath,cellFilterOutputFile)
        % FUNCTION
        %   Reads the filter navigation output file which is in text format 
        % INPUTS
        %   varargin : includes the list of text file paths of the filter
        %              navigation output
        %-----------------------------------------------------
        
        % Read the data from each given file
          n=size(cellFilterOutputFile);
          n=max(n);
          for k=1:n
              % Open the input files
                filepath = strcat(folderPath,'/',cellFilterOutputFile{k});
                this.filtEstFID=fopen(filepath,'rt+');
                this.filePath{k}=filepath;
              % Read the estimated values
                % Read file header
                  while 1
                     sline=fgetl(this.filtEstFID);
                
                     ind=strfind(sline,'Filter Type     :');
                     if ~isempty(ind);
                         split_text=regexp(sline,'Filter Type     :','split');
                         this.filterType=[sscanf(split_text{2},'%s')];
                     end     
                 
                     ind=strfind(sline,'Observation Type:');
                     if ~isempty(ind);
                         split_text=regexp(sline,'Observation Type:','split');
                         this.obsType=[sscanf(split_text{2},'%s')];
                     end   
                
                     ind=strfind(sline,'[ x y z ');
                     if ~isempty(ind);
                         tcell=textscan(sline,'%s',inf);
                         % Look for the model parameters
                           % Drag and solar radiation coefficients
                             ind=strfind(sline,'Cdrag');
                             if ~isempty(ind);
                                 this.enableCdragCrad=1;
                             end
                           % Empirical accelerations
                             ind=strfind(sline,'aR aT aN');
                             if ~isempty(ind);
                                 this.enableEmpAccel=1;
                             end      
                           % Empirical accelerations corellation time
                             ind=strfind(sline,'Ctime');
                             if ~isempty(ind);
                                 this.enableEmpCorrTime=1;
                             end                                
                         %this.stateLength=length(tcell{1})-2;
                     end
                
                     ind=strfind(sline,'FILTER OUTPUTS');
                     if ~isempty(ind);
                       break;
                     end
                
                  end
              % Read the data files
                i=1;
                while 1
                   % Read the date, time and filter prediction/update flag
                    tline=fgetl(this.filtEstFID);
                    tcell=textscan(tline,'%f %f %f %f %f %f %f');
                    data.dateTime(i,1:6)= [tcell{1} tcell{2} tcell{3} ...
                                       tcell{4} tcell{5} tcell{6}];
                    data.fFlag(i,1)=tcell{7};

                   % Read the data
                     tline=fgetl(this.filtEstFID);
                     tcell=textscan(tline,'%f' ,inf);
                     sVec=tcell{1};
                   % Read position and velocity
                     data.position(i,1:3)=[sVec(1) sVec(2) sVec(3)]; 
                     data.velocity(i,1:3)=[sVec(4) sVec(5) sVec(6)]; 
                   % Read dynamical model parameters
                      if this.enableCdragCrad==1
                         data.Cdrag(i,1)=sVec(7); 
                         data.Csrad(i,1)=sVec(8);                     
                         data.epmAccelRTN(i,1:3)=[sVec(9) sVec(10) sVec(11)];   
                         if this.enableEmpCorrTime==1
                            data.cTime(i,1)=sVec(12);                     
                         end
                      end
                   % Receiver clock Estimation
                     if strcmp(this.obsType,'Graphic') || ...
                        strcmp(this.obsType,'Code')
                        data.RecClc(i,1)=sVec(end); 
                     end
                   % End of file control
                     if feof(this.filtEstFID)
                        break
                     end
                    i=i+1;
                end
              % Store the filter output data
                this.filterData{k}=data;
                data=[];
              % Close the file
                fclose(this.filtEstFID);
          end
        end
        
        function readFilterMatOutputFile(this,folderPath,cellFilterOutputFile)
        % FUNCTION
        %   Reads the filter output file which is in mat format including
        %   internal computation data
        % INPUTS
        %   filepath : file path to mat file of the filter
        %-----------------------------------------------------
       
          n=size(cellFilterOutputFile);
          n=max(n);
          for k=1:n
              % Open the input files
                filepath = strcat(folderPath,'/',cellFilterOutputFile{k});
              % Read the data files
                matData=load(filepath,'-mat');
              % Store the filter output data
              % Take out the epoch data and store it into the class variable
                epochCount=length(fieldnames(matData));
                for i=1:epochCount
                    eval(['this.matFilterData{',num2str(i),'}=','matData.','epoch_data_',num2str(i),';'])
                end              
              % Close the file
                clear('matData');
          end
          
        end
        
        
        function [absMeanRTN,absRmsRTN,meanRTN,rmsRTN,...
                  absMeanXYZ,absRmsXYZ,meanXYZ,rmsXYZ] ...
                  =compareToJplPreciseOrbit(this,folderPath,cellPrecOrbitDataFile,...
                                            filtFlag,antOff,initFateTime,stdFlag)
        % FUNCTION
        %   Function compares the orbit filter outputs with the given
        %   precise orbit data
        % INPUTS
        %   cellPrecOrbitData :cell including jpl files 
        %   filtFlag      : if takes value "0", only epochs that 
        %                   measurement update step have been carried out 
        %                   succesfully are considered and state predictions 
        %                   are ignored.
        %   antOff        : GPS antenna offsets in m from the base location 
        %                   of the satellite in radial, tangential and normal 
        %                   directions for the precise orbit. If precise
        %                   orbit coordinates are defined directly on
        %                   satellite base location set "antOff" to [0 0 0].
        %   initFateTime  : Initial date and time to normalize all time data
        %                     [ year month day hour minute second ]
        %   stdFlag       : If set to 1, mean of components are asumed 0 in
        %                   computation of standard deviations
        % OUTPUTS
        %   absMean       : Absolute mean value of each filter outputs
        %   absRms        : RMS of each filter outputs
        %   meanRTN       : Mean value of each direction components
        %                  (radial, along track, cross track) for each filter 
        %                   outputs 
        %   rmsRTN        : RMS value of each direction components
        %                  (radial, along track, cross track) for each filter 
        %                   outputs 
        %------------------------------------------------------------------
               
        % Create auxiliary instance of classes
          timeRefSysObj=TimeAndRefSystem();
        % Load the file
          
            
            % Get the position, velocity and date data for filter outputs
              n=length(this.filterData); % Number of data file 
              
              for i=1:n   
              % Jpl data format
                jpl_format='%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f \n';                
              % Read the precise orbit file file
                filepath = strcat(folderPath,'/',cellPrecOrbitDataFile{1});
                [prn x y z vx vy vz yy m d h mm s ex ey ez evx evy evz]=...
                                              textread(filepath,jpl_format);
                % Contruct data matrix
                  precOrbitData=[yy m d h mm s x y z vx vy vz];
                  % convert position and state from km to m
                    precOrbitData(:,7:12)=precOrbitData(:,7:12)*1000;
                % Get the position, velocity and date data for precise orbit
                  precOrbPos{i}=precOrbitData(:,7:9);
                  precOrbVel{i}=precOrbitData(:,10:12);
                  precOrbFateTime{i}=precOrbitData(:,1:6);
                % Transfrom the position component of precise orbit to the
                % satellite base location
                  plen=size(precOrbPos{i});
                  if ~isempty(find(antOff))
                     for k=1:plen(1)
                         R_orb2geo=timeRefSysObj.orb2geo( ...
                                  precOrbPos{i}(k,1),precOrbPos{i}(k,2),precOrbPos{i}(k,3),...
                                  precOrbVel{i}(k,1),precOrbVel{i}(k,2),precOrbVel{i}(k,1)) ; 
                         diffPos=R_orb2geo*(-antOff(:));
                         precOrbPos{i}(k,:)=precOrbPos{i}(k,:)+diffPos';
                     end
                  end              
              end
              
              for i=1:n
                  filtPos{i}=this.filterData{i}.position;
                  filtVel{i}=this.filterData{i}.velocity;
                  filtFateTime{i}=this.filterData{i}.dateTime;
              end
            % If filtFlag is 0, remove the predicted epochs from the each
            % file
              if filtFlag==0
                 for i=1:n
                     ind=(this.filterData{i}.fFlag==0);
                     filtPos{i}=filtPos{i}(ind,:);
                     filtVel{i}=filtVel{i}(ind,:);
                     filtFateTime{i}=filtFateTime{i}(ind,:);
                 end       
              end
            % Normalize the all date and time of files with respect to inital time
              % Initial Date and Time
                initDTobj=FateTime(initFateTime);
              % Normalized date and time of precision orbit
                sizePorb = size(precOrbFateTime);
                for i=1:max(sizePorb)
                    [rP,cP]=size(precOrbFateTime{i});
                    for k=1:rP
                        precOrbDTobj= FateTime(precOrbFateTime{i}(k,:));
                        %dtPrecOrb{i}(k,1)=minus(precOrbDTobj,initDTobj)/3600;
                        dtPrecOrb{i}(k,1)=minus(precOrbDTobj,initDTobj);
                    end
                end
              % Normalize date and time of filter outputs
                for i=1:n     
                    [rF,cF]=size(filtFateTime{i});
                    for k=1:rF
                        filtOrbDTobj= FateTime(filtFateTime{i}(k,:));
                        %dtFiltOrb{i}(k,1)=minus(filtOrbDTobj,initDTobj)/3600;
                        dtFiltOrb{i}(k,1)=minus(filtOrbDTobj,initDTobj);
                    end   
                end
 
              % Find the differences of each filter output file from the precise 
              % orbit date
                for i=1:n
                    % Cubic spline approximation to precise orbit data
                      pp_val_x  =spline(dtPrecOrb{i},precOrbPos{i}(:,1));
                      pp_val_y  =spline(dtPrecOrb{i},precOrbPos{i}(:,2));
                      pp_val_z  =spline(dtPrecOrb{i},precOrbPos{i}(:,3));
                      pp_val_vx =spline(dtPrecOrb{i},precOrbVel{i}(:,1));
                      pp_val_vy =spline(dtPrecOrb{i},precOrbVel{i}(:,2));
                      pp_val_vz =spline(dtPrecOrb{i},precOrbVel{i}(:,3));                      
                    % Interpolate precise orbit to the observation time
                      pp_prec_x  =ppval(pp_val_x,dtFiltOrb{i});
                      pp_prec_y  =ppval(pp_val_y,dtFiltOrb{i});
                      pp_prec_z  =ppval(pp_val_z,dtFiltOrb{i});
                      pp_prec_vx =ppval(pp_val_vx,dtFiltOrb{i});
                      pp_prec_vy =ppval(pp_val_vy,dtFiltOrb{i});
                      pp_prec_vz =ppval(pp_val_vz,dtFiltOrb{i});  
                    % Compute State component Differences
                      diff_x{i}  = pp_prec_x-filtPos{i}(:,1);
                      diff_y{i}  = pp_prec_y-filtPos{i}(:,2);
                      diff_z{i}  = pp_prec_z-filtPos{i}(:,3);
                      diff_vx{i} = pp_prec_vx-filtVel{i}(:,1);
                      diff_vy{i} = pp_prec_vy-filtVel{i}(:,2);
                      diff_vz{i} = pp_prec_vz-filtVel{i}(:,3);
                    % Compute geocentric to orbital rotation matrix
                      [rF,cF]=size(filtPos{i});
                      for k=1:rF
                          R_orb2geo(:,:,k)=timeRefSysObj.orb2geo( ...
                                     pp_prec_x(k),pp_prec_y(k),pp_prec_z(k),...
                                     pp_prec_vx(k),pp_prec_vy(k),pp_prec_vz(k)) ; 
                      end 
                    % Compute State component Differences in orbital system
                      for k=1:rF
                          RTN_pos=R_orb2geo(:,:,k)'* ...
                                [diff_x{i}(k);diff_y{i}(k);diff_z{i}(k)];
                          RTN_vel=R_orb2geo(:,:,k)'* ...
                             [diff_vx{i}(k);diff_vy{i}(k);diff_vz{i}(k)];

                          diff_R{i}(k,1)=RTN_pos(1);
                          diff_T{i}(k,1)=RTN_pos(2);
                          diff_N{i}(k,1)=RTN_pos(3);
                          diff_Rv{i}(k,1)=RTN_vel(1);
                          diff_Tv{i}(k,1)=RTN_vel(2);
                          diff_Nv{i}(k,1)=RTN_vel(3);  
                      end
                    % Compute Statistical aspects                  
                       % Compute total position and velocity 
                         total_est_pos_diff_RTN{i}=sqrt(diff_T{i}.^2 + ...
                                                   diff_N{i}.^2 + diff_R{i}.^2);
                         total_est_vel_diff_RTN{i}=sqrt(diff_Tv{i}.^2+ ...
                                                  diff_Nv{i}.^2+ diff_Rv{i}.^2);      
                         total_est_pos_diff_XYZ{i}=sqrt(diff_x{i}.^2 + ...
                                                   diff_y{i}.^2 + diff_z{i}.^2);
                         total_est_vel_diff_XYZ{i}=sqrt(diff_vx{i}.^2+ ...
                                                  diff_vy{i}.^2+ diff_vz{i}.^2);                                            
                    % Error of each component
                      mean_est_R=mean(diff_R{i}); 
                      mean_est_T=mean(diff_T{i}); 
                      mean_est_N=mean(diff_N{i}); 
                      mean_est_Rv=mean(diff_Rv{i}); 
                      mean_est_Tv=mean(diff_Tv{i});                   
                      mean_est_Nv=mean(diff_Nv{i});                 

                      mean_est_X=mean(diff_x{i}); 
                      mean_est_Y=mean(diff_y{i}); 
                      mean_est_Z=mean(diff_z{i}); 
                      mean_est_Xv=mean(diff_vx{i});
                      mean_est_Yv=mean(diff_vy{i}); 
                      mean_est_Zv=mean(diff_vz{i}); 
                  
                      if stdFlag==1
                         std_est_T=sqrt( sum(diff_T{i}.^2)/(length(diff_T{i})-1));
                         std_est_N=sqrt( sum(diff_N{i}.^2)/(length(diff_N{i})-1));
                         std_est_R=sqrt( sum(diff_R{i}.^2)/(length(diff_R{i})-1));
                         std_est_Tv=sqrt( sum(diff_Tv{i}.^2)/(length(diff_Tv{i})-1)); 
                         std_est_Nv=sqrt( sum(diff_Nv{i}.^2)/(length(diff_Nv{i})-1)); 
                         std_est_Rv=sqrt( sum(diff_Rv{i}.^2)/(length(diff_Rv{i})-1)); 

                         std_est_X=sqrt( sum(diff_x{i}.^2)/(length(diff_x{i})-1));
                         std_est_Y=sqrt( sum(diff_y{i}.^2)/(length(diff_y{i})-1));
                         std_est_Z=sqrt( sum(diff_z{i}.^2)/(length(diff_z{i})-1));
                         std_est_Xv=sqrt( sum(diff_vx{i}.^2)/(length(diff_vx{i})-1)); 
                         std_est_Yv=sqrt( sum(diff_vy{i}.^2)/(length(diff_vy{i})-1)); 
                         std_est_Zv=sqrt( sum(diff_vz{i}.^2)/(length(diff_vz{i})-1));                      
                  
                      else
                         std_est_T=std(diff_T{i});
                         std_est_N=std(diff_N{i});
                         std_est_R=std(diff_R{i});
                         std_est_Tv=std(diff_Tv{i});
                         std_est_Nv=std(diff_Nv{i}); 
                         std_est_Rv=std(diff_Rv{i}); 

                         std_est_X=std(diff_x{i});
                         std_est_Y=std(diff_y{i});
                         std_est_Z=std(diff_z{i});
                         std_est_Xv=std(diff_vx{i});
                         std_est_Yv=std(diff_vy{i}); 
                         std_est_Zv=std(diff_vz{i});                      

                      end

                    % Total error of position and velocity
                      total_est_mean_pos_RTN = mean(total_est_pos_diff_RTN{i}) ; 
                      total_est_std_pos_RTN  = sqrt(sum(total_est_pos_diff_RTN{i}.^2)/ ...
                                               (length(total_est_pos_diff_RTN{i})-1)) ;
                      total_est_mean_vel_RTN = mean(total_est_vel_diff_RTN{i}) ; 
                      total_est_std_vel_RTN  = sqrt(sum(total_est_vel_diff_RTN{i}.^2)/ ...
                                               (length(total_est_vel_diff_RTN{i})-1)) ;     

                      total_est_mean_pos_XYZ = mean(total_est_pos_diff_XYZ{i}) ; 
                      total_est_std_pos_XYZ  = sqrt(sum(total_est_pos_diff_XYZ{i}.^2)/ ...
                                               (length(total_est_pos_diff_XYZ{i})-1)) ;
                      total_est_mean_vel_XYZ = mean(total_est_vel_diff_XYZ{i}) ; 
                      total_est_std_vel_XYZ = sqrt(sum(total_est_vel_diff_XYZ{i}.^2)/ ...
                                               (length(total_est_vel_diff_XYZ{i})-1)) ;                                         
                    % Set outputs  
                      absMeanRTN(i,:)=[total_est_mean_pos_RTN total_est_mean_vel_RTN ];
                      absRmsRTN(i,:)=[total_est_std_pos_RTN total_est_std_vel_RTN];
                      meanRTN(i,:)=[mean_est_R mean_est_T mean_est_N  ...
                                    mean_est_Rv mean_est_Tv mean_est_Nv ];
                      rmsRTN(i,:)=[std_est_R std_est_T std_est_N  ...
                                   std_est_Rv std_est_Tv std_est_Nv ];

                      absMeanXYZ(i,:)=[total_est_mean_pos_XYZ total_est_mean_vel_XYZ ];
                      absRmsXYZ(i,:)=[total_est_std_pos_XYZ total_est_std_vel_XYZ];
                      meanXYZ(i,:)=[mean_est_X mean_est_Y mean_est_Z  ...
                                    mean_est_Xv mean_est_Yv mean_est_Zv ];
                      rmsXYZ(i,:)=[std_est_X std_est_Y std_est_Z  ...
                                   std_est_Xv std_est_Yv std_est_Zv ];                           
                end
            
              % Plot Position Differences (Radial, along track, cross track)
                color_string={ 'blue','green','red', 'cyan','magenta','yellow','black'};
                figure('Name','Position differences along R,T,N')
                % Plot radial direction differences
                  R_plt=subplot(3,1,1); 
                  for i=1:n
                      hold on
                      plot(dtFiltOrb{i},diff_R{i},'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('Radial (R)'); 
                  ylabel ('m');
                  set(R_plt,'YGrid','on')
                  hold off              
                % Plot tangential direction differences
                  T_plt=subplot(3,1,2); 
                  for i=1:n
                      hold on      
                      plot(dtFiltOrb{i},diff_T{i},'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('Along Track (T)'); 
                  ylabel ('m');
                  set(T_plt,'YGrid','on')       
                  hold off
                % Plot normal direction differences
                  N_plt=subplot(3,1,3); 
                  for i=1:n
                      hold on       
                      plot(dtFiltOrb{i},diff_N{i},'.', 'LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('Cross Track (N)'); 
                  ylabel ('m');
                  set(N_plt,'YGrid','on')        
                  xlabel ('Elapsed time from initial epoch [h]'); ylabel ('m');
                  hold off
              % Plot Position Differences (X,Y,Z)              
                figure('Name','Position differences along X,Y,Z')              
                % Plot x differences
                  R_plt=subplot(3,1,1); 
                  for i=1:n
                      hold on
                      plot(dtFiltOrb{i},diff_x{i},'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('x'); 
                  ylabel ('m');
                  set(R_plt,'YGrid','on')
                  hold off              
                % Plot y differences
                  T_plt=subplot(3,1,2); 
                  for i=1:n
                      hold on      
                      plot(dtFiltOrb{i},diff_y{i},'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('y'); 
                  ylabel ('m');
                  set(T_plt,'YGrid','on')       
                  hold off
                % Plot z differences
                  N_plt=subplot(3,1,3); 
                  for i=1:n
                      hold on       
                      plot(dtFiltOrb{i},diff_z{i},'.', 'LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('z'); 
                  ylabel ('m');
                  set(N_plt,'YGrid','on')        
                  xlabel ('Elapsed time from initial epoch [h]'); ylabel ('m');
                  hold off              
              % Plot Velocity Differences
                figure ('Name','Velocity differences along R T N')
                % Plot radial direction differences
                  R_plt=subplot(3,1,1); 
                  for i=1:n
                      hold on
                      plot(dtFiltOrb{i},diff_Rv{i},'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('Radial (R)'); 
                  ylabel ('m/s^2');
                  set(R_plt,'YGrid','on')
                  hold off
              
                % Plot tangential direction differences
                  T_plt=subplot(3,1,2); 
                  for i=1:n
                      hold on      
                      plot(dtFiltOrb{i},diff_Tv{i},'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('Along Track (T)'); 
                  ylabel ('m/s^2');
                  set(T_plt,'YGrid','on')       
                  hold off
                % Plot normal direction differences
                  N_plt=subplot(3,1,3); 
                  for i=1:n
                      hold on       
                      plot(dtFiltOrb{i},diff_Nv{i},'.', 'LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('Cross Track (N)'); 
                  ylabel ('m/s^2');
                  set(N_plt,'YGrid','on')        
                  xlabel ('Elapsed time from initial epoch [h]');
                  hold off   
              % Plot Velocity Differences (X,Y,Z)              
                figure('Name','Velocity differences along X,Y,Z')              
                % Plot x differences
                  R_plt=subplot(3,1,1); 
                  for i=1:n
                      hold on
                      plot(dtFiltOrb{i},diff_vx{i},'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('Vx'); 
                  ylabel ('m/s^2');
                  set(R_plt,'YGrid','on')
                  hold off              
                % Plot y differences
                  T_plt=subplot(3,1,2); 
                  for i=1:n
                      hold on      
                      plot(dtFiltOrb{i},diff_vy{i},'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('Vy'); 
                  ylabel ('m/s^2');
                  set(T_plt,'YGrid','on')       
                  hold off
                % Plot z differences
                  N_plt=subplot(3,1,3); 
                  for i=1:n
                      hold on       
                      plot(dtFiltOrb{i},diff_vz{i},'.', 'LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('Vz'); 
                  ylabel ('m/s^2');
                  set(N_plt,'YGrid','on')        
                  xlabel ('Elapsed time from initial epoch [h]'); ylabel ('m');
                  hold off                        
              
              % Plot Absolute Position Differences
                color_string={ 'blue','green','red', 'cyan','magenta','yellow','black'};
                plot_type = {'.',''};
                figure('Name','Absolute Position Differences, RTN ')
                % Plot absolute position differences
                  pos_plt=subplot(1,1,1); 
                  for i=1:n
                      hold on
                      plot(dtFiltOrb{i},total_est_pos_diff_RTN{i},plot_type{i},'LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  %legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('Absolute Position Differences'); 
                  ylabel ('m');
                  set(pos_plt,'YGrid','on')
                  hold off

                % Plot Absolute Velocity Differences
                  color_string={ 'blue','green','red', 'cyan','magenta','yellow','black'};
                  plot_type = {'.',''};
                  figure('Name','Absolute Velocity Differences, RTN ')            
                  vel_plt=subplot(1,1,1);           
                  for i=1:n
                      hold on
                      plot(dtFiltOrb{i},total_est_vel_diff_RTN{i},plot_type{i},'LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  end
                  %legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                  title('Absolute Velocity Differences, RTN'); 
                  ylabel ('m/s^2');
                  xlabel ('Time(seconds)')
                  set(vel_plt,'YGrid','on')
                  hold off
          
    
        
        end
        
        function plotstateVectorParam(this,filtFlag,initFateTime)
        % FUNCTION
        %   Plots the estimated parameters 
        % INPUTS
        %   stateParam : string indicatinf state parameter required to be plot. 
        %                It can take the following parameters   
        %                  'Cdrad' : Atmospheric drag coefficient
        %                  'Csrad' : solar radiation coefficient
        %                  'EmpAccel' : Empirical acceleration
        %                  'RecClc' : receiver clock
        %   filtFlag      : if takes value "0", only epochs that 
        %                   measurement update step have been carried out 
        %                   succesfully are considered and state predictions 
        %                   are ignored.     
        %   initFateTime  : Initial date and time to normalize all time data
        %                     [ year month day hour minute second ]        
        % OUTPUTS
        %   absMean       : Absolute mean value of each filter outputs
        %   absRms        : RMS of each filter outputs
        %   meanRTN       : Mean value of each direction components
        %                  (radial, along track, cross track) for each filter 
        %                   outputs 
        %   rmsRTN        : RMS value of each direction components
        %                  (radial, along track, cross track) for each filter 
        %                   outputs 
        %------------------------------------------------------------------
        
        % Get the date data for filter outputs
          n=length(this.filterData); % Number of data file 
          for i=1:n
              filtFateTime{i}=this.filterData{i}.dateTime;
          end
        % If filtFlag is 0, remove the predicted epochs from the each
        % file
          if filtFlag==0
             for i=1:n
                 filtFateTime{i}=filtFateTime{i}(ind,:);
             end       
          end
        % Normalize the  time of files with respect to inital time
          % Initial Date and Time
            initDTobj=FateTime(initFateTime);
          % Normalize date and time of filter outputs
            for i=1:n     
                [rF,cF]=size(filtFateTime{i});
                for k=1:rF
                    filtOrbDTobj= FateTime(filtFateTime{i}(k,:));
                    dtFiltOrb{i}(k,1)=minus(filtOrbDTobj,initDTobj)/3600;
                end   
            end
        % Plots the state vector variables    
          % Plot Solar Radiation and atmospheric darg coefficients
            if this.enableCdragCrad==1
               color_string={ 'blue','green','red', 'cyan','magenta','yellow','black'};
               figure('Name','Solar Radiation and atmospheric darg coefficients')
               % Plot the atmospheric drag
                 Cdrag_plt=subplot(2,1,1); 
                 for i=1:n
                     hold on
                     plot(dtFiltOrb{i},this.filterData{i}.Cdrag  ,'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                 end
                 legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                 title('Atmospheric Drag Coefficient'); 
                 ylabel (' ');
                 set(Cdrag_plt,'YGrid','on')
                 hold off 
               % Plot the solar radiation coefficient
                 Csrad_plt=subplot(2,1,2); 
                 for i=1:n
                     hold on
                     plot(dtFiltOrb{i},this.filterData{i}.Csrad  ,'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                 end
                 legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                 title('Solar Radiation Coefficient'); 
                 ylabel (' ');
                 set(Csrad_plt,'YGrid','on')
                 hold off 
            end
                 
        % Plot Empirical Accelerations
          if this.enableEmpAccel==1
            figure ('Name','Empirical Accelerations, R T N')
            % Plot radial direction differences
              R_plt=subplot(3,1,1); 
              for i=1:n
                  hold on
                  plot(dtFiltOrb{i},this.filterData{i}.epmAccelRTN(:,1)*1e9,'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  'Radial',mean(this.filterData{i}.epmAccelRTN(:,1)*1e9),'+/-' , std(this.filterData{i}.epmAccelRTN(:,1)*1e9)
                  %plot(diff(this.filterData{i}.epmAccelRTN(:,1)*1e9)/30,'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ;
                  
              end
              legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
              title('Radial (R)'); 
              ylabel ('nm/s^2');
              set(R_plt,'YGrid','on')
              hold off
            % Plot tangential direction differences
              T_plt=subplot(3,1,2); 
              for i=1:n
                  hold on      
                  plot(dtFiltOrb{i},this.filterData{i}.epmAccelRTN(:,2)*1e9,'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                  'Tangential',mean(this.filterData{i}.epmAccelRTN(:,2)*1e9),'+/-' , std(this.filterData{i}.epmAccelRTN(:,2)*1e9)
                  %plot(diff(this.filterData{i}.epmAccelRTN(:,2)*1e9)/30,'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
 
              end
              legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
              title('Along Track (T)'); 
              ylabel ('nm/s^2');
              set(T_plt,'YGrid','on')       
              hold off
            % Plot normal direction differences
              N_plt=subplot(3,1,3); 
              for i=1:n
                  hold on       
                  plot(dtFiltOrb{i},this.filterData{i}.epmAccelRTN(:,3)*1e9,'.', 'LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                 'Normal',mean(this.filterData{i}.epmAccelRTN(:,3)*1e9),'+/-' , std(this.filterData{i}.epmAccelRTN(:,3)*1e9)
                  %plot(diff(this.filterData{i}.epmAccelRTN(:,3)*1e9)/30,'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
           
              end
              legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
              title('Cross Track (N)'); 
              ylabel ('nm/s^2');
              set(N_plt,'YGrid','on')        
              xlabel ('Elapsed time from initial epoch [h]'); 
              hold off 
              
        % Plots the receiver clock bias  
            if strcmp(this.obsType,'Graphic') || ...
               strcmp(this.obsType,'Code')
               c=299792458;
               color_string={ 'blue','green','red', 'cyan','magenta','yellow','black'};
               figure('Name','Receiver Clock Bias')
               % Plot the atmospheric drag
                 RecClc_plt=subplot(1,1,1); 
                 for i=1:n
                     hold on
                     plot(dtFiltOrb{i},this.filterData{i}.RecClc./c*1e6  ,'.','LineWidth',1,'MarkerSize',5,'Color',color_string{i}) ; 
                     mean(this.filterData{i}.RecClc./c*1e6), std(this.filterData{i}.RecClc./c*1e6)
                 end
                 legend(this.filePath,'Location','NorthEast','FontName','Verdana','FontSize',5,'interpreter','none')
                 ylabel ('usec');
                 xlabel ('Elapsed time from initial epoch [h]'); 
                 set(RecClc_plt,'YGrid','on')
                 hold off 
            end
             
          end
            
        end
        
        function plotCovSclMatrix(this,fromDT,toDT,initTime)
        % FUNCTION
        %   Plots the covariance scale matrix computed for robust filtering
        %   between the given date
        % INPUTS
        %   fromDT : Date and time of the beginning of the anaysis
        %                [year month date hour minute second]
        %   toDT   : Date and time of the end of the anaysis    
        %                [year month date hour minute second]  
        %   initTime : reference initial time to compute the elapsed
        %              seconds
        % OUTPUTS
        %
        %------------------------------------------------------------------
        
        % Set the initial variables
          fromDTobj=FateTime(fromDT);
          toDTobj=FateTime(toDT);
          initTimeobj=FateTime(initTime);
          epochCount=length(this.matFilterData);
        % Extract the noise covariance scaling matrix, time of epoch, 
        % satellite vehicle numbers, and innovations
          k=1;
          say = 0;
          for i=1:epochCount
              % compare the time
                epochTime=FateTime(this.matFilterData{i}.Edobj.epochFateTime);
                dt_begin=minus(epochTime,fromDTobj);
                dt_end=minus(toDTobj,epochTime);
                if dt_begin>=0 && dt_end>=0
                   % Extract the time of epoch in second with respect to
                   % initial time
                     dtEpoch(k)= minus(epochTime,initTimeobj);
                   % Extract the satellite vehicle numbers
                     svNo{k}=this.matFilterData{i}.Edobj.svn;
                   % Extract the covariance scaling matrixes
                     covScl{k}=diag(this.matFilterData{i}.SVobj.covSclMat);
                     innov{k}=abs(this.matFilterData{i}.SVobj.innov);
                   % Set the counter for next epoch
                     
                     k=k+1;
                    
                     
                         
                elseif dt_begin>0 && dt_end<0
                    break
                end
          end
        % Plot the covariance scaling matrix elements, and absolute value of
        % the innovations
          % Produce the matrix to image
            epochIntervalCount=length(dtEpoch);
            Smat=zeros(epochIntervalCount,32);  
            innovMat=zeros(epochIntervalCount,32);               
           % for i=epochIntervalCount:-1:1
            for i=1:epochIntervalCount    
                Smat(i,svNo{i})= log(covScl{i});
                
                %{
                a = covScl{i};
                for k=1:(length(a))
                    if a(k)>1e+13
                        a(k)=1;
                        covScl{i}=a;
                    end
                end
                %}
                %Smat(i,svNo{i})= covScl{i};
                innovMat(i,svNo{i})= log(innov{i});
                if log(innov{i})~= 0
                         say = say + 1
                end
                %innovMat(i,svNo{i})= innov{i};
                
            end      
        
         % Plot the image matrix
            figure
            ind = Smat>1;
            sum(sum(ind));
            bar3(Smat) 
            axis on
            %set(gca,'YLim',[dtEpoch(1) dtEpoch(end)])
            %set(gca,'XTick',1:31,'XTickLabel',1:32)
            set(gca,'YTick',1:10:epochIntervalCount,'YTickLabel',dtEpoch(1):10*(dtEpoch(2)-dtEpoch(1)):dtEpoch(end))
            set(gca,'XGrid','on'); set(gca,'YGrid','on')
            xlabel('GPS SVN')
            ylabel('Elapsed time(s)')
            title ('Diagonal components of measurement noise scale factor')  
            view(-10,20);
         % Plot the innovations 
            figure
            bar3(innovMat) 
            axis on
            set(gca,'YTick',1:10:epochIntervalCount,'YTickLabel',dtEpoch(1):10*(dtEpoch(2)-dtEpoch(1)):dtEpoch(end))
            set(gca,'XGrid','on'); set(gca,'YGrid','on')
            zlim([0; Inf]);
            xlabel('GPS SVN')
            ylabel('Elapsed time(s)')
            title ('Absolute value of innovations') 
            view(-10,20);
            
      
        
        end
        
     
        function plotObservations(this,fromDT,toDT,initTime)
        % FUNCTION
        %   Plots the observations between the given date
        % INPUTS
        %   fromDT : Date and time of the beginning of the anaysis
        %                [year month date hour minute second]
        %   toDT   : Date and time of the end of the anaysis    
        %                [year month date hour minute second]  
        %   initTime : reference initial time to compute the elapsed
        %              seconds
        % OUTPUTS
        %
        %------------------------------------------------------------------
        
        % Set the initial variables
          fromDTobj=FateTime(fromDT);
          toDTobj=FateTime(toDT);
          initTimeobj=FateTime(initTime);
          epochCount=length(this.matFilterData);
          
        % Satellite vehicle color map
          sv_color_map=[1 1 103
                        213 80 1
                        255 1 86
                        158 1 142
                        14 76 161
                        255 10 200
                        1 95 57
                        1 255 1
                        149 1 58
                        255 147 126
                        164 36 1
                        1 21 68
                        145 208 203
                        98 14 1
                        107 104 130
                        1 1 255
                        1 125 181
                        106 130 108
                        1 174 126
                        194 140 159
                        190 153 112
                        1 143 156
                        95 173 78
                        255 1 1
                        255 1 246
                        255 2 157
                        104 61 59
                        255 116 163
                        150 138 232
                        152 255 82
                        167 87 64
                        1 255 254
                        255 238 232
                        254 137 1
                        189 198 255
                        1 208 255
                        187 136 1
                        117 68 177
                        165 255 210
                        255 166 254
                        119 77 1
                        122 71 130
                        38 52 1
                        1 71 84
                        67 1 44
                        181 1 255
                        255 177 103
                        255 219 102
                        144 251 146
                        126 45 210
                        189 211 147
                        229 111 254
                        222 255 116
                        1 255 120
                        1 155 255
                        1 100 1
                        1 118 255
                        133 169 1
                        1 185 23
                        120 130 49
                        1 255 198
                        255 110 65
                        232 94 190];
               sv_color_map = 1./sv_color_map;
                
               sv_marker_map =['o','*','x','s','d','^','v','>','<','p','h' ...
                               'o','*','x','s','d','^','v','>','<','p','h' ...
                               'o','*','x','s','d','^','v','>','<','p','h'];
          
        % Plot observations
          k=1;
          % Plot L1 observations
          figure
          c = 299792458;
          lambda_L1=(c/1575.42e6);
          for i=1:epochCount
              % compare the time
                epochTime=FateTime(this.matFilterData{i}.Edobj.epochFateTime);
                dt_begin=minus(epochTime,fromDTobj);
                dt_end=minus(toDTobj,epochTime);
                if dt_begin>=0 && dt_end>=0    
                    dtEpoch= minus(epochTime,initTimeobj);
                    L1_plt=subplot(1,1,1);
                    obs = this.matFilterData{i}.Edobj.obs.L1.*lambda_L1;                    
                    svn  = this.matFilterData{i}.Edobj.svn;
                    for m =1:length(obs)
                        hold on  
                        plot(dtEpoch,obs(m) ,sv_marker_map(svn(m)),'LineWidth',1,'MarkerSize',5 ,'Color',sv_color_map(svn(m),:),'DisplayName',num2str(svn(m)) ) ; 
                    end 
                    k=k+1;
                elseif dt_begin>0 && dt_end<0
                    break
                end
          end
          ylabel ('L1 Observations (m)');
          xlabel ('Elapsed time from initial epoch [sec]'); 
          hold off              
          
          % Plot C1 observations
          figure
          for i=1:epochCount
              % compare the time
                epochTime=FateTime(this.matFilterData{i}.Edobj.epochFateTime);
                dt_begin=minus(epochTime,fromDTobj);
                dt_end=minus(toDTobj,epochTime);
                if dt_begin>=0 && dt_end>=0    
                    dtEpoch= minus(epochTime,initTimeobj);
                    C1_plt=subplot(1,1,1);
                    obs = this.matFilterData{i}.Edobj.obs.C1;                    
                    svn  = this.matFilterData{i}.Edobj.svn;
                    for m =1:length(obs)
 
                        hold on  
                        plot(dtEpoch,obs(m) ,sv_marker_map(svn(m)),'LineWidth',1,'MarkerSize',5 ,'Color',sv_color_map(svn(m),:),'DisplayName',num2str(svn(m)) ) ; 
                    end 
                    k=k+1;
                elseif dt_begin>0 && dt_end<0
                    break
                end                                
          end
          ylabel ('C1 Observations (m)');
          xlabel ('Elapsed time from initial epoch [sec]'); 
          hold off           
          
          % Plot C1 observations
          figure
          for i=1:epochCount
              % compare the time
                epochTime=FateTime(this.matFilterData{i}.Edobj.epochFateTime);
                dt_begin=minus(epochTime,fromDTobj);
                dt_end=minus(toDTobj,epochTime);
                if dt_begin>=0 && dt_end>=0    
                    dtEpoch= minus(epochTime,initTimeobj);
                    graphic_plt=subplot(1,1,1);
                    obs = this.matFilterData{i}.Edobj.obs.Graphic;
                    svn  = this.matFilterData{i}.Edobj.svn;
                    for m =1:length(obs)
 
                        hold on  
                        plot(dtEpoch,obs(m) ,sv_marker_map(svn(m)),'LineWidth',1,'MarkerSize',5 ,'Color',sv_color_map(svn(m),:),'DisplayName',num2str(svn(m)) ); 
                    end
                    k=k+1;
                elseif dt_begin>0 && dt_end<0
                    break
                end                                
          end          
          ylabel ('Graphic Observations (m)');
          xlabel ('Elapsed time from initial epoch [sec]'); 
          %legend(Leg_TEXTS);
          hold off           
          
        end        
        
    end
    
end
