classdef GeoPotNormPines < handle
    %-----------------------------------------------------------------      
    % CLASS DEFINITION
    %   This class is intended for the computation of geopotential, its first
    %   and second derivatives in terms of normalized Pines formulation.
    %
    %   Gravitational models and its implementation are based on square
    %   formulation which implies order m is equal to degree n,
    %   n_max=m_max.
    %
    % REFERENCES
    %   Erdogan, E. 2012. Pines' Gravitational Potential Formulation, its
    %       First and Second Order Derivatives: Algorithms and Matlab
    %       Implementation. Working Notes.
    %   Gottliebb, R. 1993. Fast Gravity, Gravity Partials, Normalized 
    %       Gravity, Gravity Gradient Torque and Magnetic Field: 
    %       Derivation, Code and Data. National Aeronautics and 
    %       Space Administration, Lyndon B. Johnson Space Center National
    %       Technical Information Service.
    %   Lundberg, JB. 1988. �Recursion Formulas of Legendre Functions for
    %       Use with Nonsingular Geopotential Models.� Journal of Guidance,
    %       Control and Dynamics 11 (1).
    %   Pines, S. 1973. �Uniform Representation of the Gravitational 
    %       Potential and Its Derivatives.� AIAA Journal 11 (11): 1508�1511.
    %   Spencer, J L. 1976. Pines Nonsingular Gravitational Potential 
    %       Derivation, Description and Implementation. NASA STI/Recon 
    %       Technical Report.    
    %
    % WRITTEN BY
    %   Eren Erdogan
    %   erdogan.eren@gmail.com
    %   created at 17 August 2012
    %--------------------------------------------------------------------     
    properties
        % Earth related parameters
          GM; % Earth's Gravitational constant
          Re; % Earth's mean radius 
        % Maximum number of degree of geopotential model
          n_max; 
        % Constant coefficients through the whole process
          b;c;h;j;v;w; % Coefficients for derived Legendre function 
          k;l;         % Coefficients for the first order derivatives
          e;f;g;       % Coefficients for the second order derivatives
        % Normalized Stokes coeffients
          C;S;
        % r(s,t) and i(s,t) for all values of m
          r_m; i_m;
        % mass coefficients
          Dnm;Enm;Fnm;Gnm;Hnm;
        % parallactic factor
          rho;
        % derived Legendre coefficients
          Anm;
    end
    
    methods
        function this=GeoPotNormPines(Re,C,S,GM,n_max)
        %-----------------------------------------------------------------              
        % FUNCTION
        %   Constructure function for the class "GeoPotNormPines".
        % INPUTS
        %   x,y,z : Components of position vector in x,y,z directions
        %   Re    : Earth's mean radius
        %   C,S   : Normalized Stokes coefficients
        %   Gm    : Erath's gravitational constant
        %   n_max : maximum number of degree of the Stoke's coefficient
        % OUTPUTS
        %   this : GeoPotPines object
        %-----------------------------------------------------------------    
        
        % Set the maximum degree of geopotential model for Class
            this.n_max=n_max; 
        % Set the normalized stokes coefficients
            this.C=C; this.S=S;        
        % Set the Earth related constants
            this.GM=GM; % Earth's Gravitational constant
            this.Re=Re; % Earth's mean radius
        % Compute the coefficints which are constant through the whole process.
        % Theese coefficients are inserted to the formulae due to normalization.
            this.initCoeff();
        end
        
        function initCoeff(this)
        %-----------------------------------------------------------------              
        % FUNCTION
        %   Function computes the coefficients which are constant through 
        %   the whole process. Theese coefficients are inserted to the  
        %   formulae due to normalization.
        % OUTPUTS
        %   b,c,h,j,v,w : Coefficients for derived Legendre function 
        %   k,l         : Coefficients for the first order derivatives
        %   e,f,g       : Coefficients for the second order derivatives
        %-----------------------------------------------------------------    

        % Matlab indexes begin with 1, but the model 0. Hence, increment 
        % the original gravitational model indexes.
            nn_max=this.n_max+1; 
        % Coefficients required to compute derived Legendre function 
            % Create and initialize the coefficients
              b=NaN(nn_max+2,1); c=NaN(nn_max+2,1);h=NaN(nn_max+2,1); 
              j=NaN(nn_max+2,1); v=NaN(nn_max+2,nn_max);w=NaN(nn_max+2,nn_max);
            % Compute the coefficients
              for n=2:this.n_max+2
                 nn=n+1; 
                 b(nn)=sqrt((2*n+1)/(2*n)); % b(n,n) with n=m, n>1
                 c(nn)=sqrt(2*n);         % c(n,n-1) with m=n-1, n>1
                 h(nn)=sqrt((2*n-1)*(2*n+1))/n;       % h(n,0) with m=0, n>1
                 j(nn)=((n-1)/n)*sqrt((2*n+1)/(2*n-3)); % j(n,0) with m=0, n>1
              end
              for n=3:this.n_max+2 % v(n,m) and w(n,m) with 0<m<n, n>2
                  nn=n+1; 
                  for m=0:n-1
                    mm=m+1; 
                    v(nn,mm)=sqrt(((2*n-1)*(2*n+1))/((n-m)*(n+m)));   
                    w(nn,mm)=sqrt(((2*n+1)*(n-m-1)*(n+m-1))/ ...
                                  ((2*n-3)*(n-m)*(n+m)));
                  end
              end     
              
        % Coefficients required to compute first order derivatives
            % Create and initialize the coefficients
              k=NaN(nn_max,nn_max);l=NaN(nn_max,nn_max);
            % Compute the coefficients
              for n=0:this.n_max % k(n,0)and l(n,0) with m=0
                 nn=n+1; 
                 k(nn,1)=sqrt(n*(n+1)/2);
                 l(nn,1)=sqrt(((n+1)*(n+2)*(2*n+1))/(2*(2*n+3)));
              end
              for n=0:this.n_max % k(n,m)and l(n,m) with m>0
                 nn=n+1; 
                 for m=1:n
                   mm=m+1;  
                   k(nn,mm)=sqrt((n-m)*(n+m+1));
                   l(nn,mm)=sqrt(((n+m+1)*(n+m+2)*(2*n+1))/(2*n+3));
                 end
              end  
              
        % Coefficients required to compute second order derivatives
            % Create and initialize the coefficients
              e=NaN(nn_max,nn_max);f=NaN(nn_max,nn_max);
              g=NaN(nn_max,nn_max);
            % Compute the coefficients
              for n=0:this.n_max % e(n,0), f(n,0)and l(n,0) with m=0
                 nn=n+1; 
                 e(nn,1)=sqrt((n*(n-1)*(n+1)*(n+2))/2);
                 f(nn,1)=sqrt((n*(2*n+1)*(n+1)*(n+2)*(n+3))/(2*(2*n+3)));
                 g(nn,1)=sqrt(((2*n+1)*(n+1)*(n+2)*(n+3)*(n+4))/(2*(2*n+5)));
              end
              for n=0:this.n_max % e(n,m),f(n,m)and g(n,m) with m>0
                 nn=n+1; 
                 for m=1:n
                   mm=m+1;  
                   e(nn,mm)=sqrt((n-m)*(n-m-1)*(n+m+1)*(n+m+2));
                   f(nn,mm)=sqrt(((n-m)*(2*n+1)*(n+m+1)*(n+m+2)*(n+m+3))/...
                                  (2*n+3));
                   g(nn,mm)=sqrt(((2*n+1)*(n+m+1)*(n+m+2)*(n+m+3)*(n+m+4))/...
                                  (2*n+5));
                 end
              end   
        % Set the class variables
            this.b=b; this.c=c; this.h=h; this.j=j; this.v=v; this.w=w;
            this.k=k; this.l=l; this.e=e; this.f=f; this.g=g;
        end  
        
        function compute_rm_im(this,s,t)
        %-----------------------------------------------------------------              
        % FUNCTION
        %   Function computes the values of functions rm(s,t) and im(s,t)
        %   for all m. 
        % INPUTS
        %   s,t   : indicates coordinates in terms of direction cosines.
        %           s=x/r, t=y/r 
        % OUTPUTS
        %   [r_m,i_m] : vectors including the results of the functions 
        %               rm(s,t) and im(s,t)
        %----------------------------------------------------------------- 
        
        % Compute the  r(s,t) and i(s,t) for all m.
            % Set the initial values for m=0
                r_m(1)=1;i_m(1)=0;
            % Compute the values for m > 0
                for m=1:this.n_max
                    mm=m+1;
                    r_m(mm)=s*r_m(mm-1)-t*i_m(mm-1);
                    i_m(mm)=s*i_m(mm-1)+t*r_m(mm-1);                
                end
        % Set the class variables
            this.r_m=r_m;
            this.i_m=i_m;
        end
        
        function massCoeffDnm(this)
        %-----------------------------------------------------------------              
        % FUNCTION
        %   Function computes and stores values of the mass coefficient 
        %   function D(s,t)
        %-----------------------------------------------------------------  
        
        % Compute the D(s,t) for the degree n and order m
            nn_max= this.n_max+1; % Matlab array indexes begin with 1
            Dnm=NaN(nn_max,nn_max);
            for n=0:this.n_max
                nn=n+1; 
                for m=0:n
                    mm=m+1;    
                    Dnm(nn,mm)=this.C(nn,mm)*this.r_m(mm)+ ...
                               this.S(nn,mm)*this.i_m(mm);   
                end
            end
        % Set the class variable
          this.Dnm=Dnm;        
        end
        
        function massCoeffEnm(this)
        %-----------------------------------------------------------------              
        % FUNCTION
        %   Function computes and stores values of the mass coefficient 
        %   function E(s,t)
        %-----------------------------------------------------------------  
        
        % Compute the E(s,t) for the degree n and order m
            nn_max= this.n_max+1; % Matlab array indexes begin with 1
            Enm=NaN(nn_max,nn_max);
            for n=1:this.n_max
                nn=n+1; 
                for m=1:n
                    mm=m+1;    
                    Enm(nn,mm)=this.C(nn,mm)*this.r_m(mm-1)+ ...
                               this.S(nn,mm)*this.i_m(mm-1);   
                end
            end
        % Set the class variable
          this.Enm=Enm;        
        end
        
        function massCoeffFnm(this)
        %-----------------------------------------------------------------              
        % FUNCTION
        %   Function computes and stores values of the mass coefficient 
        %   function F(s,t)
        %----------------------------------------------------------------- 
           
        % Compute the F(s,t) for the degree n and order m
            nn_max= this.n_max+1; % Matlab array indexes begin with 1
            Fnm=NaN(nn_max,nn_max);
            for n=1:this.n_max
                nn=n+1; 
                for m=1:n
                    mm=m+1;    
                    Fnm(nn,mm)=this.S(nn,mm)*this.r_m(mm-1)- ...
                               this.C(nn,mm)*this.i_m(mm-1);   
                end
            end
        % Set the class variable
          this.Fnm=Fnm;        
        end     
        
        function massCoeffGnm(this)
        %-----------------------------------------------------------------          
        % FUNCTION
        %   Function computes and stores values of the mass coefficient 
        %   function G(s,t)
        %-----------------------------------------------------------------   
        
        % Compute the G(s,t) for the degree n and order m
            nn_max= this.n_max+1; % Matlab array indexes begin with 1       
            Gnm=NaN(nn_max,nn_max);        
            for n=2:this.n_max
               nn=n+1; 
               for m=2:n
                 mm=m+1;    
                 Gnm(nn,mm)=this.C(nn,mm)*this.r_m(mm-2)+ ...
                            this.S(nn,mm)*this.i_m(mm-2);   
               end
            end
        % Set the class variable
          this.Gnm=Gnm;        
        end  
        
        function massCoeffHnm(this)
        %-----------------------------------------------------------------    
        % FUNCTION
        %   Function computes and stores values of the mass coefficient 
        %   function H(s,t)
        %-----------------------------------------------------------------  
        
        % Compute the H(s,t) for the degree n and order m
            nn_max= this.n_max+1; % Matlab array indexes begin with 1  
            Hnm=NaN(nn_max,nn_max);         
            for n=2:this.n_max
                nn=n+1; 
                for m=2:n
                    mm=m+1;    
                    Hnm(nn,mm)=this.S(nn,mm)*this.r_m(mm-2)- ...
                               this.C(nn,mm)*this.i_m(mm-2);   
                end
            end
        % Set the class variable
          this.Hnm=Hnm;        
        end     
        
        function parallacticFactor(this,r)
        %-----------------------------------------------------------------              
        % FUNCTION
        %   Function computes the parallactic factor, rho, for all values of n
        % INPUTS
        %   r: magnitude of the  of position vector r=[x;y;z]
        %-----------------------------------------------------------------  
        
        % Compute rho(0) for the degree n=0 
            rho(1)=this.GM/r;
        % Compute rho(n) for the degree n>0
            for n=1:this.n_max+2
                nn=n+1; 
                rho(nn)=(this.Re/r)*rho(nn-1); 
            end
        % Set the class variable
            this.rho=rho;        
        end
        
        function derivedLegendre(this,u)
        %-----------------------------------------------------------------              
        % FUNCTION
        %   Function computes the fully normalized derived Legendre function
        % INPUTS
        %   u   : indicates coordinates in terms of direction cosines.
        %           u=z/r
        %-----------------------------------------------------------------  
        
        % Matlab array indexes begin with 1, but the model 0. Hence, 
        % increment the original gravitational model indexes.
            nn_max=this.n_max+1;        
        % Create and initialize the Anm
            Anm=zeros(nn_max+2,nn_max+2);
        % Compute the fully normalized sectorial terms
            Anm(1,1)=1;        % for n=m=0
            Anm(2,2)=sqrt(3);  % for n=m=1
            for n=2:this.n_max+2 % for n=m>1
                nn=n+1;
                Anm(nn,nn)=this.b(nn)*Anm(nn-1,nn-1);                
            end
        % Compute the first off-diagonal normalized terms
            Anm(2,1)=u*sqrt(3);% for n=1 and m=0
            for n=2:this.n_max+2 % for m=n-1 and n>1
                nn=n+1;
                Anm(nn,nn-1)=u*this.c(nn)*Anm(nn,nn);
            end
        % Compute the fully normalized zonal and tesseral terms
            for n=2:this.n_max+2 % for m=0 and n>1
                nn=n+1;
                Anm(nn,1)=u*this.h(nn,1)*Anm(nn-1,1)- ...
                         this.j(nn,1)*Anm(nn-2,1);  
            end            
            for n=3:this.n_max+2 % for 0<m<n-2 and n>2
                nn=n+1;
                for m=1:n-2
                    mm=m+1; 
                    Anm(nn,mm)=u*this.v(nn,mm)*Anm(nn-1,mm)- ...
                               this.w(nn,mm)*Anm(nn-2,mm);
                end
            end
        % Set the class variable
          this.Anm=Anm;
        end
        
        function [U]=geoPot(this,x,y,z)
        %-----------------------------------------------------------------              
        % FUNCTION
        %   Function computes geopotential at a given point
        % INPUTS
        %   x,y,z : components of position vector r
        % OUTPUTS
        %   U     : Value of geopotential at a given point 
        %-----------------------------------------------------------------             
        
        % Compute the direction cosines, r,s,t,u
            r=norm([x y z]);
            s=x/r; t=y/r; u=z/r;        
        % Compute the  rm(s,t) and im(s,t) for all m.
            this.compute_rm_im(s,t)
        % Compute the mass coefficients Dnm for s and t
            this.massCoeffDnm()
        % Compute the parallactic factor
            this.parallacticFactor(r)
        % Compute the derived Legendre coefficients for given u
            this.derivedLegendre(u)
        % Compute the gravitational potential at the given point
            U=0; 
            for n=0:this.n_max
                nn=n+1;
                AnmDnm=0;
                for m=0:n
                    mm=m+1;
                    AnmDnm=AnmDnm+this.Anm(nn,mm)*this.Dnm(nn,mm);
                end
                U=U+AnmDnm*this.rho(nn);
            end       
        end
        
        function [du_dx,du_dy,du_dz]=firstDeriv(this,x,y,z)
        %-----------------------------------------------------------------              
        % FUNCTION
        %   Function computes the first order partial derivatives of 
        %   gravitational potential with respect to position vector r=[x;y;z]. 
        %   The results also indicates the acceleration, gradient of 
        %   gravitational potential, at a given point.  
        % INPUTS
        %   x,y,z : components of position vector r
        % OUTPUTS
        %   du_dx,du_dy,du_dz : accelerations along x,y and z directions 
        %-----------------------------------------------------------------               
        
        % Compute the direction cosines, r,s,t,u
            r=norm([x y z]);
            s=x/r; t=y/r; u=z/r;        
        % Compute the  rm(s,t) and im(s,t) for all m.
            this.compute_rm_im(s,t);
        % Compute the mass coefficients Dnm,Enm,Fnm for s and t
            this.massCoeffDnm();
            this.massCoeffEnm()
            this.massCoeffFnm()
        % Compute the parallactic factor
            this.parallacticFactor(r);
        % Compute the derived Legendre coefficients for given u
            this.derivedLegendre(u);      
        % Compute the coefficients a1,a2,a3,a4
            a1=0;a2=0;a3=0;a4=0;
            for n=0:this.n_max
                nn=n+1;
                AnmEnm=0; AnmFnm=0; Anm1Dnm=0; An1m1Dnm=0;
                for m=1:n
                    mm=m+1;
                    AnmEnm=AnmEnm+m*this.Anm(nn,mm)*this.Enm(nn,mm);
                    AnmFnm=AnmFnm+m*this.Anm(nn,mm)*this.Fnm(nn,mm);                             
                end
                for m=0:n
                    mm=m+1;
                    Anm1Dnm=Anm1Dnm+this.Anm(nn,mm+1)*this.Dnm(nn,mm)* ...
                                    this.k(nn,mm);
                    An1m1Dnm=An1m1Dnm+this.Anm(nn+1,mm+1)*this.Dnm(nn,mm)* ...
                                      this.l(nn,mm);                                
                end                
                rho_Re=this.rho(nn+1)/this.Re;
                a1=a1+AnmEnm*rho_Re; 
                a2=a2+AnmFnm*rho_Re;
                a3=a3+Anm1Dnm*rho_Re;
                a4=a4-An1m1Dnm*rho_Re;                
            end         
        % Compute the accelerations
          du_dx=a1+s*a4; du_dy=a2+t*a4; du_dz=a3+u*a4;            
        end
        
        function [d2u_dr2]=secondDeriv(this,x,y,z)
        %-----------------------------------------------------------------              
        % FUNCTION
        %   Function computes the second order partial derivatives of 
        %   gravitational potential with respect to position vector r=[x;y;z].
        % INPUTS
        %   x,y,z : components of position vector r
        % OUTPUTS
        %   d2u_dr2 : matrix including second order partial derivatives
        %-----------------------------------------------------------------               
        
        % Compute the direction cosines, r,s,t,u
            r=norm([x y z]);
            s=x/r; t=y/r; u=z/r;        
        % Compute the  rm(s,t) and im(s,t) for all m.
            this.compute_rm_im(s,t);
        % Compute the mass coefficients Dnm,Enm,Fnm for s and t
            this.massCoeffDnm();
            this.massCoeffEnm()
            this.massCoeffFnm()
            this.massCoeffGnm()
            this.massCoeffHnm()
        % Compute the parallactic factor
            this.parallacticFactor(r);
        % Compute the derived Legendre coefficients for given u
            this.derivedLegendre(u);      
        % Compute the coefficients axx
            a11=0;a12=0;a13=0;a14=0;a23=0;a24=0;a33=0;a34=0;a44=0;
            for n=0:this.n_max
                nn=n+1;
                AnmGnm=0; AnmHnm=0; Anm1Enm=0; An1m1Enm=0; Anm1Fnm=0; 
                An1m1Fnm=0; Anm2Dnm=0; An1m2Dnm=0; An2m2Dnm=0;
                for m=2:n
                    mm=m+1;
                    AnmGnm=AnmGnm+m*(m-1)*this.Anm(nn,mm)*this.Gnm(nn,mm);
                    AnmHnm=AnmHnm+m*(m-1)*this.Anm(nn,mm)*this.Hnm(nn,mm);                             
                end
                for m=1:n
                    mm=m+1;
                    Anm1Enm=Anm1Enm+m*this.Anm(nn,mm+1)*this.Enm(nn,mm)* ...
                                    this.k(nn,mm);
                    An1m1Enm=An1m1Enm+m*this.Anm(nn+1,mm+1)*this.Enm(nn,mm)* ...
                                      this.l(nn,mm);  
                    Anm1Fnm=Anm1Fnm+m*this.Anm(nn,mm+1)*this.Fnm(nn,mm)* ...
                                    this.k(nn,mm);     
                    An1m1Fnm=An1m1Fnm+m*this.Anm(nn+1,mm+1)*this.Fnm(nn,mm)* ...
                                      this.l(nn,mm);                                 
                end       
                for m=0:n
                    mm=m+1;
                    Anm2Dnm=Anm2Dnm+this.Anm(nn,mm+2)*this.Dnm(nn,mm)* ...
                                    this.e(nn,mm);
                    An1m2Dnm=An1m2Dnm+this.Anm(nn+1,mm+2)*this.Dnm(nn,mm)* ...
                                      this.f(nn,mm);  
                    An2m2Dnm=An2m2Dnm+this.Anm(nn+2,mm+2)*this.Dnm(nn,mm)* ...
                                      this.g(nn,mm);                                   
                end                 
                rho_Re2=this.rho(nn+2)/(this.Re^2);
                a11=a11+AnmGnm*rho_Re2; 
                a12=a12+AnmHnm*rho_Re2;
                a13=a13+Anm1Enm*rho_Re2;
                a14=a14-An1m1Enm*rho_Re2;
                a23=a23+Anm1Fnm*rho_Re2;
                a24=a24-An1m1Fnm*rho_Re2;
                a33=a33+Anm2Dnm*rho_Re2;
                a34=a34-An1m2Dnm*rho_Re2;
                a44=a44+An2m2Dnm*rho_Re2;
            end 
        % Compute the coefficient a4    
            a4=0; 
            An1m1Dnm=0;
            for n=0:this.n_max
                nn=n+1;
                An1m1Dnm=0;
                for m=0:n
                    mm=m+1;
                    An1m1Dnm=An1m1Dnm+this.Anm(nn+1,mm+1)*this.Dnm(nn,mm)* ...
                                      this.l(nn,mm);                                
                end                
                rho_Re=this.rho(nn+1)/this.Re;
                a4=a4-An1m1Dnm*rho_Re;                
            end          
            
        % Compute the components of matrix including second order partial 
        % derivatives
          P11=a11+2*s*a14+s^2*a44+a4/r;    
          P12=a12+t*a14+s*a24+s*t*a44;      P21=P12;     
          P13=a13+u*a14+s*a34+s*u*a44;      P31=P13;
          P22=-a11+2*t*a24+t^2*a44+a4/r;
          P23=a23+u*a24+t*a34+u*t*a44;      P32=P23;
          P33=a33+2*u*a34+u^2*a44+a4/r;  
        % Construct the matrix including second order partial derivatives
          d2u_dr2=[ P11 P12 P13 
                    P21 P22 P23
                    P31 P32 P33 ]; 
        end        
    end 
end

