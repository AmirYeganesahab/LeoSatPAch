classdef OrbKalmanFilter < OrbFilter
    %UNTITLED3 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        residualPlot;
        svnPlot;
        recClcBiasPlot;
    end
    
    methods
        function this=OrbKalmanFilter()
            
        % Create the figure handles for online plots
          this.residualPlot=figure;
          this.svnPlot=figure;
          this.recClcBiasPlot=figure;
        end
        
        function [predSVobj]=timeUpdate(this,initSVObj,dt)
        % FUNCTION
        %   Function propagete the state vector and covariance matrix to 
        %   through the time.
        % INPUTS
        %   initSVObj: instance of 'OrbStateVector' class including initial 
        %              state vector and covariance matrix
        %   dt       : propagation time interval in second 
        % OUTPUTS
        %   predSVobj: instance of 'OrbStateVector' class including propagated 
        %              state vector and covariance matrix 
        %----------------------------------------------------------------       
        
        % Propagate the state vector and covaraiance matrix
          [xp,Pp]=this.dynModelObj.propagateStateCov(initSVObj,dt,dt);
        % Compute process noise
          Q=this.dynModelObj.getProcessNoise(initSVObj,dt);
        % Update predicted covariance matrix with computed process noise
          Pp=Pp+Q;
        % Set the output parameter
          % Compute time of prediction
            initDTobj=FateTime(initSVObj.stateFateTime);          
            predDTobj=plus(initDTobj,dt);
            predStateFateTime=[get(predDTobj,'year'),...
                               get(predDTobj,'month'),...
                               get(predDTobj,'day'),...
                               get(predDTobj,'hour'),...
                               get(predDTobj,'min'),...
                               get(predDTobj,'sec')];    
          % Set parameters
            predSVobj=OrbStateVector(xp,...
                                     this.filtSet.enableDynModParam, ...
                                     this.filtSet.obsType, ...
                                     predStateFateTime);
            predSVobj.stateCov=Pp;
            predSVobj.updateFlag=1;
        end
        
        function [updSVobj,updEDobj,updateFlag]=measurementUpdate(this, ...
                                              prevEDobj,currEDobj,predSVobj)
        %-----------------------------------------------------------------             
        % FUNCTION
        %   Function performs a data editing step to remove outliers and to
        %   control elevation threshold. Than execute measurement update step 
        %   of Kalman filtering  
        % INPUTS
        %   prevEDobj : instance of 'OrbEpochData' class including observations
        %               GPS ephemerides and other auxiliary data at the
        %               previous time of epoch
        %   currEDobj : instance of 'OrbEpochData' class including observations
        %               GPS ephemerides and other auxiliary data at the
        %               current time of epoch        
        %   predSVobj : instance of 'OrbStateVector' class including predicted 
        %               state vector variables  
        % OUTPUTS
        %   updSVobj : instance of 'OrbStateVector' class including updated 
        %              state vector variables          
        %   updEDobj : instance of 'OrbEpochData' class including updated 
        %              observations, GPS ephemerides and other auxiliary data
        %   updateFlag : If measurement update step is carried out without
        %                any problem updateFlag takes the value "0", else
        %                "1". If updateFlag takes "1",updSVobj andu pdEDobj
        %                variables are set to empty value "[]"
        %   minObsFlag  : If number of minimum observations is under the 
        %                 threshold, minObsFlag takes value '1' else value '0'
        %----------------------------------------------------------------- 

        % Set the default value for the update flag
          updateFlag=0;
        
        % Transform the positions from satellite  reference system to GPS
        % antenna reference system
          %[updSVobj]=this.bodyToGps(predSVobj,'Sat2Gps');

        % Prior to measurement update, perform data editing process
          if strcmp(this.filtSet.obsType,'Graphic')
             [updSVobj,updEDobj,minObsFlag]=this.measModelObj.dataEditing(...
                                         prevEDobj,currEDobj,predSVobj);
          elseif strcmp(this.filtSet.obsType,'Code')
             [updSVobj,updEDobj,minObsFlag]=this.measModelObj.dataEditing(...
                                                   currEDobj,predSVobj);
                                               %,updSVobj)
          elseif strcmp(this.filtSet.obsType,'NavSol')
             [updSVobj,updEDobj,minObsFlag]=this.measModelObj.dataEditing(...
                                                   currEDobj,updSVobj);
          else
              error('Wrong unsupported observation type')                                               
          end
          % Control the number of minumum observations
            if minObsFlag==1
               updateFlag=1; updSVobj=[]; updEDobj=[];
               return;
            end
            
        % Kalman Update
          [updSVobj]=kalmanUpdate(this,updSVobj,updEDobj);
          
        % Transform the positions from GPS antenna reference system to 
        % satellite  reference system to
          %[updSVobj]=this.transSatSys2GpsAntSys(updSVobj,'Gps2Sat'); 
        % Set the state update vector
          updSVobj.updateFlag=0;
            
        end
        
        function [updSVobj]=kalmanUpdate(this,SVobj,EDobj)
        % FUNCTION
        %   Function performs Kalman update equations
        % INPUTS
        %   EDobj : instance of 'OrbEpochData' class including observations
        %           GPS ephemerides and other auxiliary data
        %   SVobj : instance of 'OrbStateVector' class including state
        %           vector variables  
        % OUTPUTS
        %   updSVobj: instance of 'OrbStateVector' class including updated 
        %             state vector and covariance matrix 
        %----------------------------------------------------------------  
        
        % Compute the Kalman Gain
          % Get design matrix,H
            [H]=this.measModelObj.getDesignMatrix(EDobj,SVobj);
          % Get predicted state covariance,Pp and state vector,xp
            xp=SVobj.stateVector;
            Pp=SVobj.stateCov;
          % Get the observations
            if strcmp(this.filtSet.obsType,'Graphic')
               z=EDobj.obs.Graphic; 
            elseif strcmp(this.filtSet.obsType,'Code')
               z=EDobj.obs.C1;  
            elseif strcmp(this.filtSet.obsType,'NavSol')
               z=EDobj.obs.NavSol;                 
            end
          % Compute Measurement Noise
            n=length(z);
            if strcmp(this.filtSet.obsType,'Graphic') ||...
               strcmp(this.filtSet.obsType,'Code')
                R=this.filtSet.stat.std.measurementNoise^2*eye(n);
            elseif strcmp(this.filtSet.obsType,'NavSol')
                R=diag(this.filtSet.stat.std.measurementNoise.^2);
            end
          % Kalman Gain,K
            K=(Pp*H')/(H*Pp*H'+R);
            %K=(Pp*H')*pinv(H*Pp*H'+R);
        % Compute updated state vector and covaraiance matrix
          % Get the computed observations,zc
            [zc]=this.measModelObj.getCompObs(EDobj,SVobj);
          % Compute the Residuals
            rp=z-zc;
          % Update state
            xc=xp+K*rp;
          % Update covaraiance
            I=eye(length(xp));
            Pc=(I-K*H)*Pp*(I-K*H)'+K*R*K';  
            %{
v
SVobj.recClcBias
zc-SVobj.recClcBias
xc
xc-xp
EDobj.gpsPos

z
v  
(xc-xp)
% xc'
% diag(Pc)'


% (EDobj.svn)'
% 'Pp'
% diag(Pp)'
'Pp'
diag(Pp)'
'Pc'
diag(Pc)'

            %}


        % Set the outputs
            updSVobj=OrbStateVector(xc,...
                                    this.filtSet.enableDynModParam,...
                                    this.filtSet.obsType,...
                                    SVobj.stateFateTime);
            updSVobj.stateCov=Pc;
        % Update time of state vector due to receiver clock correction 
          if strcmp(this.filtSet.obsType,'Code') || ...
             strcmp(this.filtSet.obsType,'Graphic')   
             c = 299792458;          % speed of light in vacum (m/sec)
             stateDTobj=FateTime(SVobj.stateFateTime);
             updDTobj=plus(stateDTobj,updSVobj.recClcBias/c);
             updSVobj.stateFateTime =[get(updDTobj,'year'), get(updDTobj,'month'),...
                                      get(updDTobj,'day') ,get(updDTobj,'hour'),...
                                      get(updDTobj,'min'),get(updDTobj,'sec')];
          end            
        % Online Plots
          % Plot the residuals
            filterCurrentTimeObj=FateTime(SVobj.stateFateTime);
            filterInitTimeObj=FateTime(this.filterInitTime);
            dt=minus(filterCurrentTimeObj,filterInitTimeObj);
            figure(this.residualPlot)
            plot(dt*ones(length(rp),1),rp,'.','MarkerSize',5)
            ylabel ('Residual Plot');
            hold on
% %           % Plot the tracked satellites
            figure(this.svnPlot)
            plot(dt*ones(length(rp),1),EDobj.svn,'>','MarkerSize',5)
            ylabel ('Tracked Satellites');
             hold on       
           % Plot the rceiver clock bias
            figure(this.recClcBiasPlot)
            plot(dt,updSVobj.recClcBias,'.','MarkerSize',5)
            ylabel ('Receiver Clock Bias');
            hold on
'dt'
dt
pause(0.01)         
        
        end
    end
    
end

