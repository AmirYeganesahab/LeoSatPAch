classdef NumericalIntegration < handle
    % written by : Eren Erdogan, email: erdogan.eren@gmail.com
    %              Middle East Technical University,Geomatics Division
    properties
        model_type % type of numerical integeration algorithm
    end
    
    methods
        function this=NumericalIntegration(model_type)
        % FUNCTION
        %   Class implements numerical integration algorithms
        % INPUTS
        %   model_type: type of numerical integeration algorithm. Takes the
        %       value below;
        %           model='RK4'
        % OUTPUTS
        %
        %----------------------------------------------------------------
            this.model_type=model_type;
        end
        function [x]=RK4(this,t0,x0,dt,dh,dyn_func,varargin)
        % FUNCTION
        %   [state]=RK4(state0,dh,t0,tn),varargin
        %   Runge-Kutta 4 numrical integration
        % INPUTS
        %   x0 : initial state
        %   t0 : initial time
        %   dt     : total integration time 
        %   dyn_func : m-file including dynamic model
        %   dh  : integration step size
        %   varargin : parameters for the dynamic model. RK4 algorithm pass
        %              this parameters to dynamic model as inputs
        % OUTPUTS
        %   state  : state value at time tn
        %---------------------------------------------------
          currentTime=t0;
          endTime=t0+dt;
          do=1;
          while do~=0
            if (currentTime+dh)<endTime
                interval=dh;
                currentTime=currentTime+dh;
            else
                interval=endTime-currentTime;
                do=0;
            end
            df1=dyn_func(t0,x0,varargin{:}); 
            x=x0+(interval/2).*df1;
            df2=dyn_func (t0+interval/2,x,varargin{:});
            
            x=x0+(interval/2).*df2;        
            df3=dyn_func (t0+interval/2,x,varargin{:});  

            x=x0+interval.*df3;   
            df4=dyn_func (t0+interval,x,varargin{:});    

            x=x0+(interval/6).*(df1+2.*df2+2.*df3+df4);

            t0=t0+interval;
            x0=x;
          end            
        end             
    end
    
end

